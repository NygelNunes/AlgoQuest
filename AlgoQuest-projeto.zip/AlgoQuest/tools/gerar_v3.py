# Gera V3__exercicios_adicionais.sql (ordem 6-10 de cada modulo). Uso: python3 tools/gerar_v3.py
P = {"FACIL": 10, "MEDIO": 20, "DIFICIL": 30}
Q = lambda s: s.replace("'", "''")
D = [
("Análise de Algoritmos", [
 ("FACIL","Qual notação descreve o limite superior para o crescimento do custo de um algoritmo?",["Notação Big O","Notação polonesa","Notação hexadecimal","Notação científica"],0,"Big O descreve um limite superior para o crescimento do custo (tempo ou memória) conforme a entrada aumenta."),
 ("FACIL","Qual destas complexidades cresce mais devagar quando n aumenta?",["O(n²)","O(n)","O(log n)","O(2ⁿ)"],2,"Entre as opções, O(log n) é a que menos cresce: dobrar n acrescenta apenas um passo."),
 ("MEDIO","Um laço externo roda n vezes e, dentro dele, um laço interno roda log n vezes. Qual é a complexidade total?",["O(n)","O(n²)","O(log n)","O(n log n)"],3,"São n voltas externas, cada uma com log n operações internas: n × log n, ou seja, O(n log n)."),
 ("MEDIO","Dois laços em sequência (não aninhados), cada um com n iterações. Qual é a complexidade?",["O(n²)","O(n)","O(2ⁿ)","O(log n)"],1,"n + n = 2n operações; descartando a constante, O(n). Laços em sequência somam, aninhados multiplicam."),
 ("DIFICIL","A função fib(n) = fib(n-1) + fib(n-2), sem memorização, tem qual complexidade aproximada?",["O(n)","O(n²)","O(2ⁿ)","O(log n)"],2,"Cada chamada gera duas novas, e a árvore de chamadas cresce de forma exponencial; com memorização cairia para O(n)."),
]),
("Algoritmos de Busca", [
 ("FACIL","Em um vetor desordenado, qual busca pode ser aplicada diretamente?",["Busca sequencial","Busca binária, sem ordenar antes","Nenhuma: é sempre preciso ordenar","Busca binária com pivô aleatório"],0,"A busca sequencial não exige ordem. A binária só funciona em coleções ordenadas."),
 ("FACIL","Na busca binária em [2, 5, 8, 11, 14, 17, 20] (índices 0 a 6), qual é o primeiro elemento comparado?",["2","8","11","17"],2,"O meio é o índice (0 + 6) / 2 = 3, que guarda o valor 11."),
 ("MEDIO","Quantas vezes é preciso dividir 1.024 elementos ao meio até restar apenas 1?",["5","10","32","1.024"],1,"2¹⁰ = 1.024, então bastam 10 divisões: é o log₂(1.024) por trás do O(log n)."),
 ("MEDIO","Buscando 7 em [1, 3, 5, 7, 9, 11] com baixo = 0 e alto = 5, o meio é o índice 2 (valor 5). Como 7 > 5, o que se faz?",["baixo = meio + 1","alto = meio - 1","Reiniciar do índice 0","Retornar -1 imediatamente"],0,"Se o alvo é maior que o elemento do meio, descarta-se a metade esquerda: baixo passa a meio + 1."),
 ("DIFICIL","Você fará k buscas em uma lista desordenada de n elementos, com k muito grande. Qual estratégia costuma compensar?",["Ordenar uma vez e usar busca binária nas consultas","Busca sequencial em cada consulta","Ordenar a lista antes de cada consulta","Embaralhar a lista a cada consulta"],0,"Ordenar custa O(n log n) uma única vez e cada consulta passa a custar O(log n), contra O(n) por consulta na busca sequencial."),
]),
("Algoritmos de Ordenação", [
 ("FACIL","Qual algoritmo compara pares adjacentes e os troca, fazendo os maiores valores \"subirem\" até o final?",["Bubble Sort","Selection Sort","Merge Sort","Quick Sort"],0,"O Bubble Sort percorre o vetor trocando vizinhos fora de ordem; a cada passada o maior valor restante chega ao fim."),
 ("FACIL","Qual algoritmo divide o vetor ao meio, ordena cada metade e depois as intercala?",["Bubble Sort","Selection Sort","Merge Sort","Insertion Sort"],2,"O Merge Sort usa dividir para conquistar: divide, ordena recursivamente e intercala as metades ordenadas."),
 ("MEDIO","Qual é a complexidade de tempo do Merge Sort, em qualquer caso?",["O(n)","O(n²)","O(n log n)","O(log n)"],2,"São log n níveis de divisão e, em cada nível, a intercalação custa O(n): O(n log n) sempre."),
 ("MEDIO","O que o Selection Sort faz a cada passo?",["Seleciona o menor elemento restante e o coloca na próxima posição","Troca pares adjacentes fora de ordem","Divide o vetor ao meio e intercala","Escolhe um pivô e particiona o vetor"],0,"A cada passo ele busca o menor elemento da parte não ordenada e o posiciona logo após a parte já ordenada."),
 ("DIFICIL","Qual é a complexidade do Quick Sort no pior caso (por exemplo, pivô sempre o menor elemento)?",["O(n log n)","O(n²)","O(n)","O(log n)"],1,"Com pivôs ruins as partições ficam desbalanceadas (0 e n-1 elementos), gerando n níveis de recursão: O(n²). No caso médio é O(n log n)."),
]),
("Tabelas Hash", [
 ("FACIL","Qual é o papel da função hash em uma tabela hash?",["Converter uma chave em um índice da tabela","Ordenar as chaves em ordem crescente","Criptografar os valores armazenados","Contar quantas chaves existem"],0,"A função hash transforma a chave em um índice, permitindo acessar a posição do valor diretamente."),
 ("FACIL","Qual é a complexidade média da busca em uma tabela hash bem dimensionada?",["O(1)","O(n)","O(log n)","O(n²)"],0,"Com boa função hash e poucas colisões, o acesso vai direto à posição: custo médio constante, O(1)."),
 ("MEDIO","O que é uma colisão em uma tabela hash?",["Uma chave ser removida duas vezes","Duas chaves diferentes gerarem o mesmo índice","A tabela ficar sem nenhuma chave","Uma chave ter valor nulo"],1,"Colisão ocorre quando chaves distintas resultam no mesmo índice e precisam ser tratadas (encadeamento ou endereçamento aberto)."),
 ("MEDIO","No encadeamento separado (separate chaining), como as colisões são tratadas?",["A tabela é apagada e recriada","A chave nova substitui a antiga","Cada posição guarda uma lista com as chaves que colidiram","A chave é descartada"],2,"Cada posição da tabela aponta para uma lista (ou estrutura similar) contendo todas as chaves que caíram nela."),
 ("DIFICIL","Com h(k) = k mod 7 e endereçamento aberto com sondagem linear, inserem-se 15, 22 e 8, nessa ordem, em uma tabela vazia de tamanho 7. Em qual índice fica o 8?",["Índice 1","Índice 2","Índice 3","Índice 4"],2,"15, 22 e 8 dão índice 1. O 15 ocupa o 1, o 22 colide e vai para o 2, o 8 colide com ambos e vai para o 3."),
]),
("Estruturas de Dados", [
 ("FACIL","Quantos filhos, no máximo, um nó de uma árvore binária pode ter?",["1","2","3","Ilimitados"],1,"Em uma árvore binária cada nó tem no máximo dois filhos: esquerdo e direito."),
 ("FACIL","Qual propriedade define uma árvore binária de busca (BST)?",["Para cada nó, a subárvore esquerda tem valores menores e a direita, maiores","Todos os nós têm exatamente dois filhos","Os valores são sempre inseridos em ordem crescente","Todas as folhas ficam no mesmo nível"],0,"A regra esquerda < nó < direita, válida para todos os nós, é o que torna a busca eficiente."),
 ("MEDIO","O percurso em-ordem (esquerda, raiz, direita) de uma BST visita os valores em qual ordem?",["Decrescente","Crescente","Por nível, da raiz às folhas","Aleatória"],1,"Como a esquerda guarda os menores e a direita os maiores, o percurso em-ordem produz os valores em ordem crescente."),
 ("MEDIO","Inserindo 50, 30, 70, 20 e 40, nessa ordem, em uma BST vazia, quem é o filho direito do nó 30?",["20","40","70","Nenhum"],1,"O 40 é menor que 50 (vai à esquerda) e maior que 30 (vai à direita dele)."),
 ("DIFICIL","Inserir 10, 20, 30, 40 e 50, nessa ordem, em uma BST sem balanceamento resulta em quê?",["Altura log n e busca O(log n)","Árvore degenerada (parece uma lista): altura n e busca O(n)","Altura 1 e busca O(1)","Uma árvore perfeitamente balanceada"],1,"Cada valor é maior que o anterior e vai sempre para a direita. Árvores balanceadas, como a AVL, evitam esse caso."),
]),
]
out = ["-- AlgoQuest: exercicios adicionais (ordem 6 a 10 de cada modulo; total de 10 por modulo).",
       "-- Gerado por tools/gerar_v3.py. Mesmo formato e regra de pontos do V2 (FACIL=10, MEDIO=20, DIFICIL=30).\n"]
for mod, exs in D:
    for i, (dif, desc, ops, ok, fb) in enumerate(exs):
        o = 6 + i
        sel = f"(SELECT e.id FROM exercicio e WHERE e.modulo_id = (SELECT id FROM modulo WHERE titulo = '{Q(mod)}') AND e.ordem = {o})"
        out.append(f"INSERT INTO exercicio (modulo_id, ordem, tipo, descricao, dificuldade, pontos, texto_feedback) VALUES ((SELECT id FROM modulo WHERE titulo = '{Q(mod)}'), {o}, 'MULTIPLA_ESCOLHA', '{Q(desc)}', '{dif}', {P[dif]}, '{Q(fb)}');")
        out.append(f"INSERT INTO exercicio_multipla_escolha (exercicio_id, indice_correto) VALUES ({sel}, {ok});")
        for j, t in enumerate(ops):
            out.append(f"INSERT INTO exercicio_opcao (exercicio_id, indice, texto) VALUES ({sel}, {j}, '{Q(t)}');")
    out.append("")
open("src/main/resources/db/migration/V3__exercicios_adicionais.sql", "w", encoding="utf-8").write("\n".join(out))
print("ok")
