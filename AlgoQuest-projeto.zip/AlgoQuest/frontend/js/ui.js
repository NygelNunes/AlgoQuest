// Interface compartilhada: sessao, menu e painel do personagem (sem acesso direto ao backend).
const Sessao = {
  salvar(u) { sessionStorage.setItem("aq_usuario", JSON.stringify(u)); },
  obter() { try { return JSON.parse(sessionStorage.getItem("aq_usuario")); } catch (e) { return null; } },
  limpar() { sessionStorage.removeItem("aq_usuario"); },
};
const esc = (v) => { const d = document.createElement("div"); d.textContent = v == null ? "" : String(v); return d.innerHTML; };
const ic = (nome) => `<i class="ic i-${nome}" aria-hidden="true"></i>`;
const AVATAR_PADRAO = "assets/img/avatar-padrao.jpg";
const SEM_MOVIMENTO = matchMedia("(prefers-reduced-motion: reduce)").matches;

// Anima um numero de 0 ate o valor real (apenas apresentacao; o texto final e sempre o valor verdadeiro).
function contar(el, alvo, sufixo = "") {
  const n = Number(alvo);
  if (SEM_MOVIMENTO || !Number.isFinite(n) || n === 0) { el.textContent = alvo + sufixo; return; }
  const t0 = performance.now(), dur = 900;
  const passo = (t) => {
    const k = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - k, 3);
    el.textContent = Math.round(n * e) + sufixo;
    if (k < 1) requestAnimationFrame(passo);
  };
  requestAnimationFrame(passo);
}
// Preenche barras depois do primeiro desenho, para a transicao de largura ser visivel.
function encher(escopo = document) {
  const barras = escopo.querySelectorAll("[data-largura]");
  requestAnimationFrame(() => requestAnimationFrame(() => barras.forEach((b) => { b.style.width = b.dataset.largura + "%"; })));
}

function montarMenu() {
  const m = document.getElementById("menu");
  if (!m) return;
  m.className = "menu superficie";
  m.innerHTML = `<a class="marca" href="modulos.html" aria-label="AlgoQuest">Algo<b>Quest</b></a>
    <nav class="menu__nav" aria-label="Principal">
      <a class="menu__item is-ativo" href="modulos.html" aria-current="page" title="Central de Desafios">${ic("swords")}<span>Central de Desafios</span></a>
    </nav>
    <p class="menu__lema">Aprenda. Evolua. Conquiste.</p>
    <button class="menu__sair" id="btnSair" type="button" aria-label="Sair" title="Sair">${ic("log-out")}<span>Sair</span></button>`;
  document.getElementById("btnSair").addEventListener("click", async () => {
    try { await Api.logout(); } catch (e) { /* encerra a sessao local mesmo assim */ }
    Sessao.limpar();
    window.location.href = "index.html";
  });
}

function reduzirImagem(arquivo, lado, aoTerminar) {
  const url = URL.createObjectURL(arquivo), img = new Image();
  img.onload = () => {
    const c = document.createElement("canvas"); c.width = c.height = lado;
    const t = Math.min(img.width, img.height);
    c.getContext("2d").drawImage(img, (img.width - t) / 2, (img.height - t) / 2, t, t, 0, 0, lado, lado);
    URL.revokeObjectURL(url);
    aoTerminar(c.toDataURL("image/jpeg", 0.85));
  };
  img.src = url;
}

const Perfil = {
  montar(compacto) {
    const p = document.getElementById("perfil");
    if (!p) return;
    const u = Sessao.obter();
    p.className = "perfil superficie" + (compacto ? " perfil--compacto" : "");
    if (!u) { p.innerHTML = `<p class="muted">Você não está conectado.</p><a class="btn btn--primario" href="index.html">Entrar</a>`; return; }
    const chave = "aq_avatar_" + u.nomeUsuario;
    let foto = null;
    try { foto = localStorage.getItem(chave); } catch (e) { /* sem armazenamento local */ }
    const xp = u.xp ?? 0, nivel = u.nivel ?? 1, meta = u.xpProximoNivel; // barra de XP so se o backend informar a meta
    const stats = `<dl class="stats">
        <div>${ic("crown")}<dd>${esc(nivel)}</dd><dt>Nível</dt></div>
        <div>${ic("zap")}<dd>${esc(xp)}</dd><dt>XP</dt></div>
        <div>${ic("star")}<dd>${esc(u.pontuacao ?? 0)}</dd><dt>Pontos</dt></div></dl>`;
    const troca = `<label class="perfil__trocar" title="Alterar imagem">${ic("camera")}<span class="sr">Alterar imagem do perfil</span>
        <input class="sr" id="arqAvatar" type="file" accept="image/*"></label>`;
    const nota = `<p class="perfil__nota" id="notaAvatar">A imagem fica salva apenas neste navegador; ainda não é enviada ao servidor.</p>`;
    const barraXp = meta ? `<div class="perfil__xp"><div><span>Experiência</span><span>${esc(xp)} / ${esc(meta)} XP</span></div>
        <div class="trilha trilha--xp"><i data-largura="${Math.min(100, (xp / meta) * 100)}"></i></div></div>` : "";
    if (compacto) {
      p.innerHTML = `<details><summary><span class="mini__moldura"><img class="mini" id="retrato" src="${esc(foto || AVATAR_PADRAO)}" alt="Retrato de ${esc(u.nomeUsuario)}"></span>
        <span class="mini__txt"><b>${esc(u.nomeUsuario)}</b><span>Nível ${esc(nivel)} · ${esc(xp)} XP · ${esc(u.pontuacao ?? 0)} pts</span></span>${ic("chevron-down")}</summary>
        <div class="detalhes">${stats}${troca}${barraXp}${nota}</div></details>`;
    } else {
      p.innerHTML = `<div class="perfil__moldura"><img class="perfil__retrato" id="retrato" src="${esc(foto || AVATAR_PADRAO)}" alt="Retrato de ${esc(u.nomeUsuario)}">
          <span class="perfil__nivel-selo" title="Nível ${esc(nivel)}"><b>${esc(nivel)}</b></span>${troca}</div>
        <div class="perfil__id"><h2 class="perfil__nome">${esc(u.nomeUsuario)}</h2><p class="perfil__nivel">Nível ${esc(nivel)}</p></div>${barraXp}${stats}
        <div class="perfil__geral" id="progGeral" hidden><div><span>Progresso geral</span><b id="progGeralPct"></b></div><div class="trilha"><i id="progGeralBarra"></i></div></div>${nota}`;
    }
    encher(p);
    if (Perfil._pct != null) Perfil.progresso(Perfil._pct);
    document.getElementById("arqAvatar").addEventListener("change", (e) => {
      const arq = e.target.files[0];
      if (!arq) return;
      reduzirImagem(arq, 384, (dados) => {
        document.getElementById("retrato").src = dados;
        try { localStorage.setItem(chave, dados); } catch (err) {
          document.getElementById("notaAvatar").textContent = "Pré-visualização apenas: não foi possível guardar a imagem neste navegador.";
        }
      });
    });
  },
  // Atualiza o usuario guardado na sessao (mantendo o token) e redesenha o painel se algo mudou.
  atualizarUsuario(novo) {
    const atual = Sessao.obter();
    if (!atual || !novo) return;
    const mudou = ["pontuacao", "xp", "nivel", "xpProximoNivel"].some((k) => atual[k] !== novo[k]);
    Sessao.salvar({ ...atual, ...novo });
    if (mudou) montarPerfilAtual();
  },
  progresso(pct) {
    Perfil._pct = pct;
    const g = document.getElementById("progGeral");
    if (!g) return;
    g.hidden = false;
    document.getElementById("progGeralPct").textContent = pct + "%";
    const b = document.getElementById("progGeralBarra");
    b.dataset.largura = pct; encher(g);
  },
};
montarMenu();
// Telas de foco (exercicio): perfil completo em telas largas (mesma grade do painel), compacto nas demais.
const perfilCompacto = document.body.dataset.perfil === "compacto";
const telaLarga = matchMedia("(min-width:1280px)");
const montarPerfilAtual = () => Perfil.montar(perfilCompacto && !telaLarga.matches);
montarPerfilAtual();
if (perfilCompacto) telaLarga.addEventListener("change", montarPerfilAtual);
// Nivel, XP e pontos vem do banco: ao abrir qualquer tela, sincroniza com o servidor.
// (Se a API nao responder, mantem os dados do login; 401 e tratado em api.js.)
Api.eu().then((u) => Perfil.atualizarUsuario(u)).catch(() => {});
