const params = new URLSearchParams(window.location.search);
const idModulo = params.get("modulo");
const NIVEL = { FACIL: ["Fácil", 1], MEDIO: ["Médio", 2], DIFICIL: ["Difícil", 3] };
let exercicios = [];
let atual = 0;
let tituloModulo = "Módulo";
const $ = (id) => document.getElementById(id);

function mostrarFeedback(ok, texto) {
  const f = $("feedback");
  f.hidden = false;
  f.className = "feedback " + (ok ? "ok" : "erro");
  f.innerHTML = ic(ok ? "circle-check" : "circle-x") + "<span>" + esc(texto) + "</span>";
}
// Reinicia a animacao de entrada do corpo do desafio a cada troca de exercicio.
function entrada() {
  const c = $("corpo");
  c.classList.remove("entra"); void c.offsetWidth; c.classList.add("entra");
}

function renderizarExercicio(ex) {
  const total = exercicios.length;
  $("feedback").hidden = true;
  $("btnProximo").hidden = true;
  $("btnConcluir").hidden = true;
  $("btnAnterior").hidden = atual === 0;
  $("btnProximo").textContent = "Próximo desafio";
  $("numero").textContent = "Desafio " + (atual + 1) + " de " + total;
  $("barra").style.width = (atual / total) * 100 + "%";
  $("trilha").setAttribute("aria-valuenow", atual);
  $("trilha").setAttribute("aria-valuemax", total);
  const [rotulo, n] = NIVEL[ex.dificuldade] || [ex.dificuldade, 1];
  $("dificuldade").className = "dificuldade " + esc(ex.dificuldade);
  $("dificuldade").innerHTML = `<span class="pips">${[1, 2, 3].map((k) => `<i class="${k <= n ? "on" : ""}"></i>`).join("")}</span>${esc(rotulo)}`;
  $("pontos").innerHTML = ic("star") + esc(ex.pontos) + " pts";
  $("descricao").textContent = ex.descricao;
  $("opcoes").innerHTML = (ex.opcoes || []).map((o, i) =>
    `<button class="opcao" type="button" data-i="${i}" style="--k:${i}"><span class="opcao__letra">${String.fromCharCode(65 + i)}</span><span class="opcao__texto">${esc(o)}</span></button>`).join("");
  entrada();
  document.querySelectorAll(".opcao").forEach((btn) =>
    btn.addEventListener("click", async () => {
      if (btn.classList.contains("errada")) return;
      try {
        const resultado = await Api.responder(ex.id, Number(btn.dataset.i));
        const correta = resultado && resultado.correta;
        if (resultado && resultado.usuario) Perfil.atualizarUsuario(resultado.usuario);
        btn.classList.add(correta ? "certa" : "errada");
        mostrarFeedback(correta, correta ? "Correto! " + (resultado.feedback || "") : "Tente novamente.");
        if (correta) {
          document.querySelectorAll(".opcao").forEach((b) => (b.disabled = true));
          $("barra").style.width = ((atual + 1) / total) * 100 + "%";
          if (atual < total - 1) $("btnProximo").hidden = false; else $("btnConcluir").hidden = false;
        }
      } catch (e) {
        mostrarFeedback(false, "Não foi possível enviar a resposta.");
      }
    }));
}

async function iniciar() {
  try {
    const modulo = await Api.abrirModulo(idModulo);
    if (modulo && modulo.titulo) tituloModulo = modulo.titulo;
    const tema = temaDe(tituloModulo);
    $("moduloNome").textContent = tituloModulo;
    $("moduloSelo").innerHTML = `<span class="hex">${ic(TEMAS[tema].icone)}</span>`;
    $("desafio").style.setProperty("--tom", TEMAS[tema].tom);
    exercicios = Array.isArray(modulo) ? modulo : (modulo && modulo.exercicios) || [];
    if (exercicios.length === 0) { $("descricao").textContent = "Este módulo ainda não tem exercícios."; return; }
    renderizarExercicio(exercicios[atual]);
  } catch (e) {
    $("descricao").textContent = "Erro ao carregar o exercício.";
  }
}
$("btnProximo").addEventListener("click", () => { atual++; renderizarExercicio(exercicios[atual]); });
$("btnAnterior").addEventListener("click", () => { atual--; renderizarExercicio(exercicios[atual]); });
iniciar();
