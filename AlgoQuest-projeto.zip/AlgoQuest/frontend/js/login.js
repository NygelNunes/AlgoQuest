// Login: validacao, estados de carregamento e mensagens. O contrato com o backend (Api.login) nao mudou.
const $ = (id) => document.getElementById(id);
const form = $("formLogin"), campoUsuario = $("usuario"), campoSenha = $("senha"), botao = $("btnEntrar");

function marcarErro(campo, texto) {
  const caixa = campo.closest(".campo");
  caixa.classList.toggle("campo--erro", !!texto);
  campo.setAttribute("aria-invalid", texto ? "true" : "false");
  caixa.querySelector(".campo__erro").textContent = texto || "";
}
function mostrarAlerta(texto) {
  const a = $("erro");
  a.hidden = !texto;
  a.innerHTML = texto ? '<i class="ic i-triangle-alert" aria-hidden="true"></i><span></span>' : "";
  if (texto) a.querySelector("span").textContent = texto;
}
function ocupado(sim) {
  botao.disabled = sim;
  botao.classList.toggle("is-carregando", sim);
  botao.querySelector(".btn__rotulo").textContent = sim ? "Entrando..." : "Entrar";
  form.setAttribute("aria-busy", String(sim));
  campoUsuario.readOnly = campoSenha.readOnly = sim;
}
function sacudir() {
  form.classList.remove("portal--recusa"); void form.offsetWidth; form.classList.add("portal--recusa");
}

async function entrar(ev) {
  ev.preventDefault();
  mostrarAlerta("");
  const usuario = campoUsuario.value.trim(), senha = campoSenha.value;
  marcarErro(campoUsuario, usuario ? "" : "Informe seu usuário.");
  marcarErro(campoSenha, senha ? "" : "Informe sua senha.");
  if (!usuario || !senha) { sacudir(); (usuario ? campoSenha : campoUsuario).focus(); return; }
  ocupado(true);
  try {
    const dados = await Api.login(usuario, senha);
    const { senha: _descartada, ...publico } = dados || {}; // nunca guardar a senha no navegador
    Sessao.salvar({ nomeUsuario: usuario, ...publico });
    botao.classList.add("is-ok");
    window.location.href = "modulos.html";
  } catch (e) {
    // "Erro 4xx/5xx" = o servidor respondeu e recusou; qualquer outra falha = sem conexao.
    const recusado = e && /^Erro \d+/.test(e.message);
    mostrarAlerta(recusado ? "Usuário ou senha incorretos. Confira os dados e tente de novo."
                           : "Não foi possível falar com o servidor. Verifique se o backend está em execução.");
    ocupado(false); sacudir();
    if (recusado) { campoSenha.select(); }
  }
}
form.addEventListener("submit", entrar);
[campoUsuario, campoSenha].forEach((c) => c.addEventListener("input", () => { marcarErro(c, ""); mostrarAlerta(""); }));

// Mostrar/ocultar senha
$("btnOlho").addEventListener("click", (ev) => {
  const b = ev.currentTarget, mostrar = campoSenha.type === "password";
  campoSenha.type = mostrar ? "text" : "password";
  b.setAttribute("aria-pressed", String(mostrar));
  b.setAttribute("aria-label", mostrar ? "Ocultar senha" : "Mostrar senha");
  b.querySelector(".ic").className = "ic " + (mostrar ? "i-eye-off" : "i-eye");
  campoSenha.focus();
});
// Aviso de Caps Lock
const caps = (e) => { if (e.getModifierState) $("avisoCaps").hidden = !e.getModifierState("CapsLock"); };
campoSenha.addEventListener("keydown", caps); campoSenha.addEventListener("keyup", caps);
campoSenha.addEventListener("blur", () => { $("avisoCaps").hidden = true; });

// Brasas: poucas particulas, so se o usuario aceita movimento.
if (!matchMedia("(prefers-reduced-motion: reduce)").matches) {
  const b = $("brasas");
  for (let i = 0; i < 16; i++) {
    const s = document.createElement("i");
    s.style.cssText = `left:${(Math.random() * 100).toFixed(1)}%;--d:${(9 + Math.random() * 10).toFixed(1)}s;--a:${(-Math.random() * 14).toFixed(1)}s;--x:${(Math.random() * 60 - 30).toFixed(0)}px;--t:${(2 + Math.random() * 2.5).toFixed(1)}px`;
    b.appendChild(s);
  }
}
campoUsuario.focus({ preventScroll: true });
