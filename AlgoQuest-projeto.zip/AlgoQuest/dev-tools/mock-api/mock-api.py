#!/usr/bin/env python3
"""DEV-ONLY (NAO e o backend). Mock de desenvolvimento do backend AlgoQuest (NAO faz parte do backend).
Existe porque os endpoints reais ainda sao stubs vazios (TODO). Serve /api na porta 8080 e o frontend na 5500.
Uso: python3 mock-api.py  (de dentro da pasta que contem frontend/)  | senha "errada" simula 401; "lenta" atrasa 1,2 s."""
import json, re, sys, threading, os
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer, SimpleHTTPRequestHandler
MODS = [
 (1,"Análise de Algoritmos","Notação Big O: compare O(1), O(n) e O(log n) e descubra como o custo cresce.",100,6),
 (2,"Algoritmos de Busca","Busca sequencial contra busca binária: encontre valores sem percorrer o reino inteiro.",60,5),
 (3,"Algoritmos de Ordenação","Bubble, Selection, Insertion, Merge e Quick Sort: coloque o caos em ordem.",0,7),
 (4,"Tabelas Hash","Funções de espalhamento, colisões e endereçamento: encontre qualquer tesouro no acervo.",0,5),
 (5,"Estruturas de Dados","Árvores binárias, de busca e balanceamento: domine as ramificações do conhecimento.",0,6)]
EX = [
 ("Você tem 1.000.000 de elementos ordenados. Qual estratégia encontra um valor com menos comparações?",["Busca sequencial","Busca binária","Ordenar de novo a cada consulta","Sortear posições ao acaso"],1,"FACIL",10),
 ("Qual é a complexidade da busca binária no pior caso?",["O(n)","O(1)","O(log n)","O(n²)"],2,"MEDIO",20),
 ("Uma lista com 1.024 elementos ordenados. No máximo quantas comparações a busca binária faz?",["10 ou 11","512","1.024","32"],0,"MEDIO",20),
 ("Em uma busca binária, o que acontece quando o valor procurado é menor que o elemento do meio?",["Descarta-se a metade esquerda","Descarta-se a metade direita","Recomeça-se do início","A busca termina sem resultado"],1,"DIFICIL",30),
 ("Qual pré-condição é indispensável para aplicar a busca binária?",["Elementos únicos","Quantidade par de elementos","Coleção ordenada","Valores numéricos"],2,"FACIL",10)]
def ex_list(mid):
    return [{"id":mid*100+i,"descricao":d,"opcoes":o,"dificuldade":dif,"pontos":p} for i,(d,o,c,dif,p) in enumerate(EX)]
class API(BaseHTTPRequestHandler):
    def _s(self,code=200,body=None):
        self.send_response(code); self.send_header("Access-Control-Allow-Origin","*"); self.send_header("Access-Control-Allow-Headers","*"); self.send_header("Access-Control-Allow-Methods","*")
        if body is not None: self.send_header("Content-Type","application/json")
        self.end_headers()
        if body is not None: self.wfile.write(json.dumps(body).encode())
    def do_OPTIONS(self): self._s(204)
    def do_GET(self):
        if self.path=="/api/modulos": return self._s(200,[{"id":i,"titulo":t,"descricao":d,"porcentagem":p,"quantidadeExercicios":q} for i,t,d,p,q in MODS])
        if self.path=="/api/auth/me": return self._s(200,{"id":1,"nomeUsuario":"mock","pontuacao":120,"xp":340,"nivel":3})
        m=re.match(r"/api/modulos/(\d+)$",self.path)
        if m:
            i=int(m.group(1)); t=next((x for x in MODS if x[0]==i),MODS[0]); return self._s(200,{"id":t[0],"titulo":t[1],"exercicios":ex_list(t[0])})
        self._s(404,{})
    def do_POST(self):
        n=int(self.headers.get("Content-Length") or 0); raw=self.rfile.read(n).decode() if n else "{}"
        if self.path=="/api/auth/login":
            d=json.loads(raw or "{}")
            if d.get("senha")=="lenta": import time; time.sleep(1.2)
            if d.get("senha")=="errada": return self._s(401,{})
            return self._s(200,{"id":1,"nomeUsuario":d.get("nomeUsuario"),"pontuacao":120,"xp":340,"nivel":3})
        if self.path=="/api/auth/logout": return self._s(200)
        m=re.match(r"/api/modulos/exercicios/(\d+)/resposta$",self.path)
        if m:
            eid=int(m.group(1)); idx=eid%100; r=json.loads(raw).get("resposta")
            ok = r==EX[idx][2]; return self._s(200,{"correta":ok,"feedback":"A busca binária divide o espaço de busca pela metade a cada passo." if ok else ""})
        self._s(404,{})
    def log_message(self,*a): pass
class Static(SimpleHTTPRequestHandler):
    def __init__(s,*a,**k): super().__init__(*a,directory=os.path.join(os.getcwd(),"frontend"),**k)
    def log_message(self,*a): pass
    def end_headers(self): self.send_header("Cache-Control","no-store"); super().end_headers()
if __name__=="__main__":
    threading.Thread(target=ThreadingHTTPServer(("127.0.0.1",8080),API).serve_forever,daemon=True).start()
    print("API :8080  |  frontend :5500"); ThreadingHTTPServer(("127.0.0.1",5500),Static).serve_forever()
