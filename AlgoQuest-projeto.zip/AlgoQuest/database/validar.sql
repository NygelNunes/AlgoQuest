-- Conferencia rapida: deve listar 5 modulos com 10 exercicios cada.
SELECT m.ordem, m.titulo, COUNT(e.id) AS exercicios, SUM(e.pontos) AS pontos_totais
FROM modulo m LEFT JOIN exercicio e ON e.modulo_id = m.id GROUP BY m.ordem, m.titulo ORDER BY m.ordem;
