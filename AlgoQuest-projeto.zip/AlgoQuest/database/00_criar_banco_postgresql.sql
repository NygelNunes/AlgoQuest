-- AlgoQuest: criacao do banco e do usuario no PostgreSQL.
-- Execute como superusuario (ex.: psql -U postgres -f database/00_criar_banco_postgresql.sql).
-- TROQUE a senha abaixo e use a mesma em ALGOQUEST_DB_SENHA.
CREATE USER algoquest WITH PASSWORD 'troque-esta-senha';
CREATE DATABASE algoquest OWNER algoquest ENCODING 'UTF8';
