package algoquest.config;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Marca um parametro {@code Usuario} de controller como "usuario autenticado desta requisicao".
 * Endpoints que declaram o parametro ficam protegidos: sem token valido a resposta e 401.
 */
@Target(ElementType.PARAMETER)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface UsuarioAutenticado {
}
