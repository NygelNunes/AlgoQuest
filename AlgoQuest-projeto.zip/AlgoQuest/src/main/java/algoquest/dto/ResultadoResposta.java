package algoquest.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * Resultado de POST /api/modulos/exercicios/{id}/resposta.
 * {@code correta} e {@code feedback} sao lidos pelo frontend; o restante e informativo.
 * {@code feedback} so e enviado quando a resposta esta correta. {@code pontosGanhos} e 0 em respostas
 * erradas e em exercicios ja concluidos antes (nada e concedido duas vezes).
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record ResultadoResposta(boolean correta, String feedback, int pontosGanhos, UsuarioResposta usuario) {
}
