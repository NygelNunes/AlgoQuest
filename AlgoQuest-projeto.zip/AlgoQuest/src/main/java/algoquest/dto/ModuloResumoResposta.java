package algoquest.dto;

import algoquest.model.Modulo;

/** Item de GET /api/modulos. {@code porcentagem} e do usuario autenticado (0 a 100). */
public record ModuloResumoResposta(int id, String titulo, String descricao, double porcentagem,
                                   int quantidadeExercicios) {

    public static ModuloResumoResposta de(Modulo m, double porcentagem) {
        double arredondada = Math.round(porcentagem * 100.0) / 100.0;
        return new ModuloResumoResposta(m.getId(), m.getTitulo(), m.getDescricao(), arredondada,
                m.getQuantidadeExercicios());
    }
}
