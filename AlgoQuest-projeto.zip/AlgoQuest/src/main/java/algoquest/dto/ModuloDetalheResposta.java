package algoquest.dto;

import java.util.List;

import algoquest.model.Exercicio;
import algoquest.model.ExercicioMultiplaEscolha;
import algoquest.model.Modulo;

/**
 * GET /api/modulos/{id}. O exercicio publico NAO tem campo de resposta correta nem feedback:
 * a correcao acontece apenas no servidor.
 */
public record ModuloDetalheResposta(int id, String titulo, String descricao, List<ExercicioResposta> exercicios) {

    public record ExercicioResposta(int id, String descricao, List<String> opcoes, String dificuldade, int pontos) {

        static ExercicioResposta de(Exercicio e) {
            List<String> opcoes = e instanceof ExercicioMultiplaEscolha m ? List.copyOf(m.getOpcoes()) : List.of();
            return new ExercicioResposta(e.getId(), e.getDescricao(), opcoes, e.getDificuldade().name(), e.getPontos());
        }
    }

    public static ModuloDetalheResposta de(Modulo m) {
        return new ModuloDetalheResposta(m.getId(), m.getTitulo(), m.getDescricao(),
                m.getExercicios().stream().map(ExercicioResposta::de).toList());
    }
}
