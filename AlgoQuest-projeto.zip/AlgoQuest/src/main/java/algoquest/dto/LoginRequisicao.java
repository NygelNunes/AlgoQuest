package algoquest.dto;

/** Corpo de POST /api/auth/login (mesmos nomes enviados por frontend/js/api.js). */
public record LoginRequisicao(String nomeUsuario, String senha) {
}
