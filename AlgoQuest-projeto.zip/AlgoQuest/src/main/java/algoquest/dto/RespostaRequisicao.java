package algoquest.dto;

/** Corpo de POST /api/modulos/exercicios/{id}/resposta: indice da opcao escolhida (Number). */
public record RespostaRequisicao(Object resposta) {
}
