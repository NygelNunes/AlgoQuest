package algoquest.repository;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import algoquest.model.Dificuldade;
import algoquest.model.Exercicio;
import algoquest.model.ExercicioMultiplaEscolha;
import algoquest.model.Modulo;

/** Modulo e raiz do agregado: carrega seus exercicios (com opcoes e indice correto, so para uso interno). */
@Repository
public class ModuloRepositorio implements Repositorio<Modulo> {

    private static final String SQL_EXERCICIOS =
            "SELECT e.id, e.modulo_id, e.descricao, e.dificuldade, e.pontos, e.texto_feedback, m.indice_correto "
            + "FROM exercicio e JOIN exercicio_multipla_escolha m ON m.exercicio_id = e.id ";

    private final JdbcTemplate jdbc;
    private final SimpleJdbcInsert insercaoModulo;
    private final SimpleJdbcInsert insercaoExercicio;

    public ModuloRepositorio(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
        this.insercaoModulo = new SimpleJdbcInsert(jdbc).withTableName("modulo").usingGeneratedKeyColumns("id")
                .usingColumns("titulo", "descricao", "ordem", "ativo");
        this.insercaoExercicio = new SimpleJdbcInsert(jdbc).withTableName("exercicio").usingGeneratedKeyColumns("id")
                .usingColumns("modulo_id", "ordem", "tipo", "descricao", "dificuldade", "pontos", "texto_feedback");
    }

    /** Insere um modulo novo (id == 0) com seus exercicios, ou atualiza titulo/descricao de um existente. */
    @Override
    public void salvar(Modulo modulo) {
        if (modulo.getId() != 0) {
            jdbc.update("UPDATE modulo SET titulo = ?, descricao = ? WHERE id = ?",
                    modulo.getTitulo(), modulo.getDescricao(), modulo.getId());
            return;
        }
        int ordemModulo = jdbc.queryForObject("SELECT COALESCE(MAX(ordem), 0) + 1 FROM modulo", Integer.class);
        modulo.setId(insercaoModulo.executeAndReturnKey(Map.of(
                "titulo", modulo.getTitulo(), "descricao", modulo.getDescricao(),
                "ordem", ordemModulo, "ativo", true)).intValue());
        int ordem = 1;
        for (Exercicio e : modulo.getExercicios()) {
            if (!(e instanceof ExercicioMultiplaEscolha me)) {
                throw new IllegalArgumentException("Tipo de exercicio nao suportado: " + e.getClass().getSimpleName());
            }
            Map<String, Object> v = new java.util.HashMap<>();
            v.put("modulo_id", modulo.getId());
            v.put("ordem", ordem++);
            v.put("tipo", "MULTIPLA_ESCOLHA");
            v.put("descricao", me.getDescricao());
            v.put("dificuldade", me.getDificuldade().name());
            v.put("pontos", me.getPontos());
            v.put("texto_feedback", me.getTextoFeedback());
            me.setId(insercaoExercicio.executeAndReturnKey(v).intValue());
            jdbc.update("INSERT INTO exercicio_multipla_escolha (exercicio_id, indice_correto) VALUES (?, ?)",
                    me.getId(), me.getIndiceCorreto());
            for (int i = 0; i < me.getOpcoes().size(); i++) {
                jdbc.update("INSERT INTO exercicio_opcao (exercicio_id, indice, texto) VALUES (?, ?, ?)",
                        me.getId(), i, me.getOpcoes().get(i));
            }
        }
    }

    /** Qualquer modulo (ativo ou nao). Retorna null quando nao existe. */
    @Override
    public Modulo buscarPorId(int id) {
        return buscarUm("SELECT id, titulo, descricao FROM modulo WHERE id = ?", id);
    }

    /** Somente modulos ativos: e o que a API publica expoe. Retorna null quando nao existe ou esta inativo. */
    public Modulo buscarAtivoPorId(int id) {
        return buscarUm("SELECT id, titulo, descricao FROM modulo WHERE id = ? AND ativo = TRUE", id);
    }

    @Override
    public List<Modulo> buscarTodos() {
        return listar("SELECT id, titulo, descricao FROM modulo ORDER BY ordem, id");
    }

    @Override
    public void deletar(int id) {
        jdbc.update("DELETE FROM modulo WHERE id = ?", id);
    }

    public List<Modulo> buscarModulosAtivos() {
        return listar("SELECT id, titulo, descricao FROM modulo WHERE ativo = TRUE ORDER BY ordem, id");
    }

    /** Exercicio de um modulo ativo, incluindo o indice correto (uso interno do servidor). Null se nao existir. */
    public Exercicio buscarExercicioPorId(int idExercicio) {
        List<ExercicioMultiplaEscolha> r = jdbc.query(
                SQL_EXERCICIOS + "JOIN modulo mo ON mo.id = e.modulo_id AND mo.ativo = TRUE WHERE e.id = ?",
                (rs, n) -> montarExercicio(rs), idExercicio);
        if (r.isEmpty()) {
            return null;
        }
        ExercicioMultiplaEscolha ex = r.get(0);
        ex.setOpcoes(jdbc.queryForList("SELECT texto FROM exercicio_opcao WHERE exercicio_id = ? ORDER BY indice",
                String.class, idExercicio));
        return ex;
    }

    // ---- carga do agregado ----

    private Modulo buscarUm(String sql, int id) {
        List<Modulo> r = new ArrayList<>(jdbc.query(sql, (rs, n) ->
                new Modulo(rs.getInt("id"), rs.getString("titulo"), rs.getString("descricao")), id));
        if (r.isEmpty()) {
            return null;
        }
        Modulo m = r.get(0);
        carregarExercicios(Map.of(m.getId(), m));
        return m;
    }

    private List<Modulo> listar(String sql) {
        Map<Integer, Modulo> porId = new LinkedHashMap<>();
        jdbc.query(sql, rs -> {
            porId.put(rs.getInt("id"), new Modulo(rs.getInt("id"), rs.getString("titulo"), rs.getString("descricao")));
        });
        carregarExercicios(porId);
        return new ArrayList<>(porId.values());
    }

    /** Duas consultas (exercicios e opcoes) restritas aos modulos informados, sem N+1. Tudo parametrizado. */
    private void carregarExercicios(Map<Integer, Modulo> modulos) {
        if (modulos.isEmpty()) {
            return;
        }
        Object[] ids = modulos.keySet().toArray();
        String marcadores = String.join(",", java.util.Collections.nCopies(ids.length, "?"));
        Map<Integer, ExercicioMultiplaEscolha> porId = new LinkedHashMap<>();
        jdbc.query(SQL_EXERCICIOS + "WHERE e.modulo_id IN (" + marcadores + ") ORDER BY e.modulo_id, e.ordem, e.id", rs -> {
            ExercicioMultiplaEscolha ex = montarExercicio(rs);
            porId.put(ex.getId(), ex);
            modulos.get(rs.getInt("modulo_id")).adicionarExercicio(ex);
        }, ids);
        jdbc.query("SELECT exercicio_id, texto FROM exercicio_opcao WHERE exercicio_id IN "
                + "(SELECT id FROM exercicio WHERE modulo_id IN (" + marcadores + ")) ORDER BY exercicio_id, indice", rs -> {
            porId.get(rs.getInt("exercicio_id")).getOpcoes().add(rs.getString("texto"));
        }, ids);
    }

    private static ExercicioMultiplaEscolha montarExercicio(java.sql.ResultSet rs) throws java.sql.SQLException {
        return new ExercicioMultiplaEscolha(rs.getInt("id"), rs.getString("descricao"),
                Dificuldade.valueOf(rs.getString("dificuldade")), rs.getInt("pontos"),
                rs.getString("texto_feedback"), new ArrayList<>(), rs.getInt("indice_correto"));
    }
}
