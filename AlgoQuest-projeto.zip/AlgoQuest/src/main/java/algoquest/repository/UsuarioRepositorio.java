package algoquest.repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import algoquest.model.Usuario;

@Repository
public class UsuarioRepositorio implements Repositorio<Usuario> {

    private static final String COLUNAS = "id, nome_usuario, senha_hash, pontuacao, xp, nivel";
    private static final RowMapper<Usuario> MAPEADOR = (rs, n) -> new Usuario(
            rs.getInt("id"), rs.getString("nome_usuario"), rs.getString("senha_hash"),
            rs.getInt("pontuacao"), rs.getInt("xp"), rs.getInt("nivel"));

    private final JdbcTemplate jdbc;
    private final SimpleJdbcInsert insercao;

    public UsuarioRepositorio(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
        this.insercao = new SimpleJdbcInsert(jdbc).withTableName("usuario").usingGeneratedKeyColumns("id")
                .usingColumns("nome_usuario", "senha_hash", "pontuacao", "xp", "nivel");
    }

    /** Insere (id == 0, preenchendo o id gerado) ou atualiza todos os campos do usuario existente. */
    @Override
    public void salvar(Usuario u) {
        if (u.getId() == 0) {
            Map<String, Object> valores = new HashMap<>();
            valores.put("nome_usuario", u.getNomeUsuario());
            valores.put("senha_hash", u.getSenha());
            valores.put("pontuacao", u.getPontuacao());
            valores.put("xp", u.getXp());
            valores.put("nivel", u.getNivel());
            u.setId(insercao.executeAndReturnKey(valores).intValue());
        } else {
            jdbc.update("UPDATE usuario SET nome_usuario = ?, senha_hash = ?, pontuacao = ?, xp = ?, nivel = ? WHERE id = ?",
                    u.getNomeUsuario(), u.getSenha(), u.getPontuacao(), u.getXp(), u.getNivel(), u.getId());
        }
    }

    /** Retorna null quando nao existe. */
    @Override
    public Usuario buscarPorId(int id) {
        List<Usuario> r = jdbc.query("SELECT " + COLUNAS + " FROM usuario WHERE id = ?", MAPEADOR, id);
        return r.isEmpty() ? null : r.get(0);
    }

    @Override
    public List<Usuario> buscarTodos() {
        return jdbc.query("SELECT " + COLUNAS + " FROM usuario ORDER BY id", MAPEADOR);
    }

    @Override
    public void deletar(int id) {
        jdbc.update("DELETE FROM usuario WHERE id = ?", id);
    }

    /** Comparacao exata (diferencia maiusculas de minusculas). Retorna null quando nao existe. */
    public Usuario buscarPorNome(String nomeUsuario) {
        List<Usuario> r = jdbc.query("SELECT " + COLUNAS + " FROM usuario WHERE nome_usuario = ?", MAPEADOR, nomeUsuario);
        return r.isEmpty() ? null : r.get(0);
    }

    /**
     * Le o usuario travando a linha ate o fim da transacao corrente. Serializa concessoes de pontos/XP do
     * mesmo usuario (duas respostas simultaneas nao premiam duas vezes). Use dentro de uma transacao.
     */
    public Usuario buscarPorIdParaAtualizar(int id) {
        List<Usuario> r = jdbc.query("SELECT " + COLUNAS + " FROM usuario WHERE id = ? FOR UPDATE", MAPEADOR, id);
        return r.isEmpty() ? null : r.get(0);
    }
}
