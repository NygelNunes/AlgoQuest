package algoquest.repository;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import algoquest.model.ProgressoUsuario;

/** Persistencia de ProgressoUsuario: uma linha (usuario, exercicio) por exercicio concluido. */
@Repository
public class ProgressoRepositorio {

    private final JdbcTemplate jdbc;

    public ProgressoRepositorio(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public ProgressoUsuario buscarPorUsuario(int idUsuario) {
        List<Integer> ids = jdbc.queryForList(
                "SELECT exercicio_id FROM progresso_usuario WHERE usuario_id = ? ORDER BY exercicio_id",
                Integer.class, idUsuario);
        return new ProgressoUsuario(idUsuario, new java.util.ArrayList<>(ids));
    }

    /** Grava a conclusao. A chave primaria (usuario, exercicio) rejeita duplicatas. */
    public void registrarConclusao(int idUsuario, int idExercicio) {
        jdbc.update("INSERT INTO progresso_usuario (usuario_id, exercicio_id) VALUES (?, ?)", idUsuario, idExercicio);
    }
}
