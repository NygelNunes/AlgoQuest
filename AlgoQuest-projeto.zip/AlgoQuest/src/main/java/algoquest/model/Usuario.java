package algoquest.model;

public class Usuario {

    private int id;
    private String nomeUsuario;
    private String senha; // armazena o HASH da senha (PBKDF2), nunca o texto puro
    private int pontuacao;
    private int xp;
    private int nivel;

    public Usuario() {
        this.nivel = 1;
    }

    public Usuario(int id, String nomeUsuario, String senha) {
        this.id = id;
        this.nomeUsuario = nomeUsuario;
        this.senha = senha;
        this.pontuacao = 0;
        this.xp = 0;
        this.nivel = 1;
    }

    public Usuario(int id, String nomeUsuario, String senha, int pontuacao, int xp, int nivel) {
        this.id = id;
        this.nomeUsuario = nomeUsuario;
        this.senha = senha;
        this.pontuacao = pontuacao;
        this.xp = xp;
        this.nivel = nivel;
    }

    /**
     * Regra de nivel (nao definida no README, necessaria para a progressao funcionar):
     * a cada XP_POR_NIVEL de XP acumulado o usuario sobe um nivel.
     * Nivel 1 ate 99 XP, nivel 2 de 100 a 199 XP, e assim por diante.
     */
    public static final int XP_POR_NIVEL = 100;

    public void adicionarPontos(int pontos) {
        if (pontos < 0) {
            throw new IllegalArgumentException("Pontos nao podem ser negativos");
        }
        this.pontuacao += pontos;
    }

    public void adicionarXp(int quantidadeXp) {
        if (quantidadeXp < 0) {
            throw new IllegalArgumentException("XP nao pode ser negativo");
        }
        this.xp += quantidadeXp;
        while (this.xp >= this.nivel * XP_POR_NIVEL) {
            subirNivel();
        }
    }

    public void subirNivel() {
        this.nivel++;
    }

    /** XP total em que o usuario alcanca o proximo nivel. */
    public int getXpProximoNivel() {
        return nivel * XP_POR_NIVEL;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNomeUsuario() { return nomeUsuario; }
    public void setNomeUsuario(String nomeUsuario) { this.nomeUsuario = nomeUsuario; }

    public String getSenha() { return senha; }
    public void setSenha(String senha) { this.senha = senha; }

    public int getPontuacao() { return pontuacao; }
    public void setPontuacao(int pontuacao) { this.pontuacao = pontuacao; }

    public int getXp() { return xp; }
    public void setXp(int xp) { this.xp = xp; }

    public int getNivel() { return nivel; }
    public void setNivel(int nivel) { this.nivel = nivel; }
}
