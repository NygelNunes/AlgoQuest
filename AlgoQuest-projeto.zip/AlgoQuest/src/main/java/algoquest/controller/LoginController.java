package algoquest.controller;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import algoquest.config.UsuarioAutenticado;
import algoquest.dto.LoginRequisicao;
import algoquest.dto.UsuarioResposta;
import algoquest.exception.ErroApi;
import algoquest.model.Usuario;
import algoquest.service.ServicoAutenticacao;

@RestController
@RequestMapping("/api/auth")
public class LoginController {

    private final ServicoAutenticacao autenticacao;

    public LoginController(ServicoAutenticacao autenticacao) {
        this.autenticacao = autenticacao;
    }

    /** 200 com o usuario (+ token), 400 se faltar campo, 401 se as credenciais estiverem erradas. */
    @PostMapping("/login")
    public UsuarioResposta login(@RequestBody LoginRequisicao requisicao) {
        if (requisicao == null) {
            throw ErroApi.requisicaoInvalida("Informe usuário e senha.");
        }
        return autenticacao.login(requisicao.nomeUsuario(), requisicao.senha());
    }

    /** 204 sempre (idempotente): apaga a sessao do token informado, se existir. */
    @PostMapping("/logout")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void logout(@RequestHeader(value = "Authorization", required = false) String autorizacao) {
        autenticacao.logout(autorizacao);
    }

    /** Dados atuais do usuario autenticado (nivel, XP e pontos vindos do banco). */
    @GetMapping("/me")
    public UsuarioResposta eu(@UsuarioAutenticado Usuario usuario) {
        return UsuarioResposta.de(usuario);
    }
}
