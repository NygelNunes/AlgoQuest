package algoquest.service;

import org.springframework.stereotype.Service;

import algoquest.model.Exercicio;
import algoquest.model.Usuario;

/**
 * Regras de recompensa. Concede os pontos do exercicio (campo {@code pontos}, o mesmo valor que o frontend
 * exibe como "N pts"; os exercicios iniciais seguem o README: FACIL=10, MEDIO=20, DIFICIL=30) e o mesmo valor
 * em XP; a subida de nivel e regra de {@link Usuario}. Esta classe NAO verifica duplicidade: quem a chama
 * (ServicoResposta) garante que cada exercicio premia uma unica vez por usuario.
 */
@Service
public class ServicoGamificacao {

    public void processarRespostaCorreta(Usuario usuario, Exercicio exercicio) {
        usuario.adicionarPontos(exercicio.getPontos());
        usuario.adicionarXp(exercicio.getPontos());
    }
}
