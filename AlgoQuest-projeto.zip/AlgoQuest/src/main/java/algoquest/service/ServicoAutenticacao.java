package algoquest.service;

import java.time.Duration;
import java.time.Instant;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import algoquest.dto.UsuarioResposta;
import algoquest.exception.ErroApi;
import algoquest.model.Usuario;
import algoquest.repository.SessaoRepositorio;
import algoquest.repository.UsuarioRepositorio;
import algoquest.util.HashSenha;

/**
 * Autenticacao por token opaco: o login devolve um token aleatorio (so o SHA-256 dele e gravado) que o
 * frontend envia em "Authorization: Bearer ...". Logout apaga a sessao, entao o token deixa de valer de fato.
 */
@Service
public class ServicoAutenticacao {

    static final int MAX_NOME = 50;
    static final int MAX_SENHA = 128;
    private static final String PREFIXO = "bearer ";
    private static final String MSG_CREDENCIAIS = "Usuário ou senha incorretos.";

    private final UsuarioRepositorio usuarios;
    private final SessaoRepositorio sessoes;
    private final HashSenha hashSenha;
    private final Duration validade;

    public ServicoAutenticacao(UsuarioRepositorio usuarios, SessaoRepositorio sessoes, HashSenha hashSenha,
                               @Value("${algoquest.sessao.horas:12}") long horas) {
        this.usuarios = usuarios;
        this.sessoes = sessoes;
        this.hashSenha = hashSenha;
        this.validade = Duration.ofHours(horas);
    }

    public UsuarioResposta login(String nomeUsuario, String senha) {
        if (nomeUsuario == null || nomeUsuario.isBlank() || senha == null || senha.isEmpty()) {
            throw ErroApi.requisicaoInvalida("Informe usuário e senha.");
        }
        String nome = nomeUsuario.trim();
        if (nome.length() > MAX_NOME || senha.length() > MAX_SENHA) {
            throw ErroApi.naoAutenticado(MSG_CREDENCIAIS);
        }
        Usuario usuario = usuarios.buscarPorNome(nome);
        if (usuario == null) {
            hashSenha.verificarFalso(senha); // mesmo custo de tempo: nao revela se o usuario existe
            throw ErroApi.naoAutenticado(MSG_CREDENCIAIS);
        }
        if (!hashSenha.verificar(senha, usuario.getSenha())) {
            throw ErroApi.naoAutenticado(MSG_CREDENCIAIS);
        }
        Instant agora = Instant.now();
        sessoes.removerExpiradas(agora);
        String token = HashSenha.gerarToken();
        sessoes.criar(HashSenha.hashDeToken(token), usuario.getId(), agora.plus(validade));
        return UsuarioResposta.comToken(usuario, token);
    }

    /** Usuario dono do token do cabecalho Authorization, lido do banco (dados sempre atuais). */
    public Usuario autenticar(String cabecalhoAutorizacao) {
        String token = extrairToken(cabecalhoAutorizacao);
        if (token == null) {
            throw ErroApi.naoAutenticado("Autenticação necessária.");
        }
        Integer idUsuario = sessoes.buscarIdUsuarioValido(HashSenha.hashDeToken(token), Instant.now());
        Usuario usuario = idUsuario == null ? null : usuarios.buscarPorId(idUsuario);
        if (usuario == null) {
            throw ErroApi.naoAutenticado("Sessão inválida ou expirada. Entre novamente.");
        }
        return usuario;
    }

    /** Idempotente: encerrar uma sessao inexistente ou ja encerrada nao e erro. */
    public void logout(String cabecalhoAutorizacao) {
        String token = extrairToken(cabecalhoAutorizacao);
        if (token != null) {
            sessoes.remover(HashSenha.hashDeToken(token));
        }
    }

    private static String extrairToken(String cabecalho) {
        if (cabecalho == null || cabecalho.length() <= PREFIXO.length()
                || !cabecalho.regionMatches(true, 0, PREFIXO, 0, PREFIXO.length())) {
            return null;
        }
        String token = cabecalho.substring(PREFIXO.length()).trim();
        return token.isEmpty() || token.length() > 200 ? null : token;
    }
}
