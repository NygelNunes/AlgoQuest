package algoquest.util;

import algoquest.model.Usuario;

/**
 * Singleton original do projeto (usuario "da sessao" em memoria).
 * ATENCAO: a API HTTP NAO usa esta classe para autenticar requisicoes. Um unico usuario global
 * compartilhado entre todas as requisicoes misturaria sessoes de pessoas diferentes; a API usa tokens
 * por usuario (ver ServicoAutenticacao). Mantida sem alteracoes para uso local/desktop.
 */
public class SessaoUsuario {

    private static SessaoUsuario instanciaUnica;
    private Usuario usuarioAtual;

    private SessaoUsuario() {
    }

    public static SessaoUsuario getInstancia() {
        if (instanciaUnica == null) {
            instanciaUnica = new SessaoUsuario();
        }
        return instanciaUnica;
    }

    public Usuario getUsuarioAtual() {
        return usuarioAtual;
    }

    public void setUsuarioAtual(Usuario usuarioAtual) {
        this.usuarioAtual = usuarioAtual;
    }

    public void limparSessao() {
        this.usuarioAtual = null;
    }
}
