# AlgoQuest — Relatório de integração backend ↔ frontend

## 1. Situação encontrada
- Backend original: apenas `LoginController` e `ModuloController` com métodos vazios (TODO) e repositórios/serviços/modelos com TODOs; **sem banco de dados** (pom só tinha `starter-web`). O frontend funcionava somente com o mock (`mock-api.py`), na mesma porta 8080.
- O README descreve Repository e Singleton (e um TODO de Strategy). **Facade, Proxy, Chain of Responsibility e Command não existem no repositório**, portanto não foram inventados. O `SessaoUsuario` (Singleton global) não é adequado para autenticar requisições HTTP e foi mantido intocado (comentado como não usado pela API).
- Cadastro público e recuperação de senha não existem e não foram criados.

## 2. Relatório de compatibilidade de endpoints
| Endpoint | Frontend envia/espera | Backend agora |
|---|---|---|
| `POST /api/auth/login` | `{nomeUsuario, senha}` → `{id, nomeUsuario, pontuacao, xp, nivel, xpProximoNivel?}` | 200 usuário + `token`; 400 campos ausentes/JSON inválido; 401 credenciais erradas (mensagem genérica) |
| `POST /api/auth/logout` | sem corpo, erro ignorado | 204 sempre; apaga a sessão no banco (token deixa de valer) |
| `GET /api/auth/me` (**novo**) | — | 200 dados atuais do banco; 401 sem token |
| `GET /api/modulos` | `[{id,titulo,descricao,porcentagem,quantidadeExercicios}]` | idem, `porcentagem` do usuário autenticado; só módulos ativos; 401 sem token |
| `GET /api/modulos/{id}` | `{id,titulo,exercicios:[{id,descricao,opcoes,dificuldade,pontos}]}` | idem; **sem resposta correta nem feedback**; 404 inexistente/inativo; 400 id inválido |
| `POST /api/modulos/exercicios/{id}/resposta` | `{resposta:<índice>}` → `{correta, feedback}` | idem + `pontosGanhos` e `usuario` (mesmo formato do login); correção no servidor; 400 resposta inválida; 404 exercício inexistente |

Nomes: o usuário usa **`pontuacao`** (o frontend nunca lê `pontos` do usuário); `pontos` é o valor do **exercício**. Um único formato de usuário (`UsuarioResposta`) em login, `/me` e respostas.

## 3. Alterações no frontend (mínimas, necessárias)
1. `js/api.js`: envia `Authorization: Bearer <token>` (o front não enviava credencial alguma); em 401 limpa a sessão e volta ao login; endereço da API usa o host da página na porta 8080 (ou `window.AQ_API_URL`); novo `Api.eu()`.
2. `js/ui.js`: sincroniza nível/XP/pontos com `/api/auth/me` ao abrir cada tela e expõe `Perfil.atualizarUsuario`.
3. `js/exercicio.js`: aplica o `usuario` devolvido na resposta (perfil atualiza sem recarregar).
Nenhuma mudança visual.

## 4. Regras de negócio
- Pontos concedidos = `pontos` do exercício (seed segue o README: Fácil 10, Médio 20, Difícil 30). XP concedido = mesmo valor.
- **Regra necessária e não definida no README:** sobe 1 nível a cada 100 XP (`Usuario.XP_POR_NIVEL`); `xpProximoNivel = nivel × 100` (faz a barra de XP do frontend aparecer).
- Cada exercício premia **uma única vez** por usuário: linha do usuário travada (`FOR UPDATE`) + chave primária (usuario, exercicio) numa transação. Reenvio responde `correta:true` com `pontosGanhos:0`.
- Conteúdo inicial (`V2__conteudo_inicial.sql`): 5 módulos do README × 5 exercícios, **redigidos por mim — revise o conteúdo**. Não há usuários fictícios: crie o seu via `ALGOQUEST_USUARIO_INICIAL/_SENHA_INICIAL`.

## 5. Banco e segurança
Flyway: `V1` (esquema derivado do modelo de domínio) e `V2` (conteúdo). SQL portável H2/PostgreSQL. Senhas: PBKDF2-HMAC-SHA256 (600 mil iterações, sal aleatório, só JDK). Tokens: 256 bits aleatórios, só o SHA-256 vai ao banco, validade configurável. Consultas 100% parametrizadas. CORS restrito a `ALGOQUEST_CORS_ORIGENS`. Erros 500 sem detalhes internos. Nenhuma credencial no código.

## 6. Resultados dos testes — LEIA: o que foi e o que NÃO foi verificado
**Ambiente:** o Maven Central era inacessível, então **Spring Boot 3.3.5 não pôde ser baixado nem executado**. Usei como substituto Spring Framework 4.3 + Jetty 9 + H2 2.2 (pacotes do Ubuntu).
- ✅ **Testes automatizados (33/33)**, código real (controllers, serviços, repositórios JDBC) sobre H2 real com as migrações reais, sem mock: login, 401/400/404, proteção, logout real, expiração, isolamento por usuário, subida de nível, repetição, 16 envios simultâneos premiando uma vez, injeção SQL, 500 sem vazamento, hash de senha.
- ✅ **E2E no navegador (27/27)**, frontend real → classes reais do backend via HTTP → H2 em arquivo: login inválido/válido, módulos do banco, exercício sem gabarito, resposta errada/certa, XP/pontos persistidos, recarga, reenvio sem prêmio, 404, CORS (origem permitida/negada), **reinício do backend preservando dados**, logout com token rejeitado.
- ❌ **Não verificado:** `mvn spring-boot:run` / `mvn test` sob Spring Boot 3.3.5; Flyway executando (apliquei os mesmos arquivos SQL por JDBC); **PostgreSQL** (só H2); `pom.xml` (dependências, inclusive `flyway-database-postgresql`) e `application.properties`. O código usa só APIs idênticas no Spring 6 (sem `@Transactional`/CGLIB/servlet API), mas **rode `mvn test` primeiro**; se algo falhar, é provável que seja configuração de build.
- Nada disso usou `mock-api.py`.

## 7. Limitações / pendências
- Foto de perfil continua só no navegador (persistir exigiria endpoint + coluna + mudança de UI).
- Sem cadastro público, recuperação de senha, limite de tentativas de login ou conquistas (não existem no projeto).
- Token fica em `sessionStorage` (padrão do projeto); usar HTTPS fora do ambiente local.
- Nome de usuário é comparado exatamente (maiúsculas/minúsculas importam).

## 8. Atualização (sessão final) — banco e exercícios
- Nova migração `V3__exercicios_adicionais.sql`: +5 exercícios por módulo (agora 10 × 5 = 50), mesmo formato e regra de pontos. V1 e V2 não foram alterados (checksums do Flyway preservados).
- Testes ajustados à nova contagem (`ApiIntegracaoTest`, `AmbienteTeste` aplica V1+V2+V3).
- Scripts avulsos em `database/` (criação do banco PostgreSQL, esquema, população, validação) e `docker-compose.yml` opcional.
- **Verificado:** esquema + exercícios (avulsos e via V1→V2→V3) executados em PostgreSQL real: 5 módulos, 50 exercícios, 200 opções, 4 opções e gabarito válido por exercício, pontos conforme a dificuldade, sem ordens duplicadas.
- **Não verificado (sem Maven Central/H2 neste ambiente):** `mvn test` / `mvn spring-boot:run` e H2 com o V3 (SQL no mesmo formato do V2). Rode `mvn test` primeiro.

## 9. Revisão de arquitetura e diagramas
- README e diagrama estavam desatualizados (falavam de persistência em JSON/memória e mostravam o `SessaoUsuario` como parte ativa). Diagrama refeito a partir do código; ver `docs/ARQUITETURA.md` e `docs/diagramas/`.
- Nenhum código Java foi alterado nesta revisão.
