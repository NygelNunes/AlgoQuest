# AlgoQuest — Arquitetura

Este documento descreve a arquitetura **como ela está implementada hoje** (código em `src/main/java/algoquest`). Os diagramas ficam em `docs/diagramas/` (fonte `.mmd`/`.svg` + `.png` pronto para colar em documentos).

## 1. Visão geral por camadas (MVC + Service + Repository)

![Visão geral](diagramas/01-visao-geral-camadas.png)

O AlgoQuest é uma **API REST** (Spring Boot) com frontend separado (HTML/CSS/JS). Por isso o MVC aparece assim:

| Camada MVC | O que é no projeto | Pacote / pasta |
|---|---|---|
| **Model** | Entidades de domínio e suas regras (pontos, XP, nível, % do módulo, correção da resposta) | `model` |
| **View** | O que o usuário vê: telas do frontend e a representação JSON devolvida pela API (DTOs) | `frontend/` + `dto` |
| **Controller** | Recebe HTTP, valida o básico e delega | `controller` |
| *Service* (extra) | Regras de aplicação que coordenam modelo e persistência | `service` |
| *Repository* (extra) | Acesso ao banco via JDBC | `repository` |
| *Infraestrutura* | Autenticação por token, tratamento de erros, CORS, hash de senha, usuário inicial | `config`, `exception`, `util` |

Fluxo: `Frontend → Controller → Service → Repository → Model` (a resposta volta como DTO).

## 2. Camada Model (diagrama de classes do domínio)

```mermaid
classDiagram
    direction LR

    class Usuario {
        +XP_POR_NIVEL : int = 100
        -int id
        -String nomeUsuario
        -String senha  «hash PBKDF2»
        -int pontuacao
        -int xp
        -int nivel
        +adicionarPontos(int pontos)
        +adicionarXp(int quantidadeXp)
        +subirNivel()
        +getXpProximoNivel() int
    }

    class ProgressoUsuario {
        -int idUsuario
        -List~Integer~ exerciciosConcluidos
        +marcarExercicioConcluido(int idExercicio)
        +isConcluido(int idExercicio) boolean
    }

    class Modulo {
        -int id
        -String titulo
        -String descricao
        -List~Exercicio~ exercicios
        +adicionarExercicio(Exercicio exercicio)
        +getQuantidadeExercicios() int
        +calcularPorcentagem(ProgressoUsuario progresso) double
    }

    class Exercicio {
        <<abstract>>
        -int id
        -String descricao
        -Dificuldade dificuldade
        -int pontos
        -String textoFeedback
        +verificarResposta(Object resposta) boolean*
    }

    class ExercicioMultiplaEscolha {
        -List~String~ opcoes
        -int indiceCorreto
        +verificarResposta(Object resposta) boolean
        -converterIndice(Object resposta) int
    }

    class Dificuldade {
        <<enumeration>>
        FACIL
        MEDIO
        DIFICIL
    }

    Modulo "1" o-- "0..*" Exercicio : contém
    Exercicio <|-- ExercicioMultiplaEscolha : estende
    Exercicio "*" --> "1" Dificuldade
    ProgressoUsuario "0..1" .. "1" Usuario : ligado por idUsuario
    Modulo ..> ProgressoUsuario : calcula % concluída

    note for Modulo "Raiz do agregado: ModuloRepositorio<br/>carrega o módulo com todos os exercícios."
    note for ExercicioMultiplaEscolha "Única subclasse hoje. Cada novo tipo<br/>de exercício implementa sua própria<br/>verificarResposta (ponto de extensão)."
    note for ProgressoUsuario "Referencia o usuário apenas pelo id<br/>(não guarda objeto Usuario)."

    style Usuario fill:#e0f2fe,stroke:#0284c7,stroke-width:2px,color:#000000
    style ProgressoUsuario fill:#e0f2fe,stroke:#0284c7,stroke-width:2px,color:#000000
    style Modulo fill:#e0f2fe,stroke:#0284c7,stroke-width:2px,color:#000000
    style Exercicio fill:#e0f2fe,stroke:#0284c7,stroke-width:2px,color:#000000
    style ExercicioMultiplaEscolha fill:#e0f2fe,stroke:#0284c7,stroke-width:2px,color:#000000
    style Dificuldade fill:#ffedd5,stroke:#c2410c,stroke-width:2px,color:#000000
```

Regras que vivem no Model: `Usuario` sobe 1 nível a cada 100 XP (`XP_POR_NIVEL`); `Modulo.calcularPorcentagem` usa o `ProgressoUsuario`; a correção é polimórfica via `Exercicio.verificarResposta`.

## 3. Persistência (padrão Repository)

```mermaid
classDiagram
    direction TB

    class Repositorio~T~ {
        <<interface>>
        +salvar(T entidade)
        +buscarPorId(int id) T
        +buscarTodos() List~T~
        +deletar(int id)
    }

    class UsuarioRepositorio {
        <<Repository>>
        +buscarPorNome(String nomeUsuario) Usuario
        +buscarPorIdParaAtualizar(int id) Usuario
    }

    class ModuloRepositorio {
        <<Repository>>
        +buscarModulosAtivos() List~Modulo~
        +buscarAtivoPorId(int id) Modulo
        +buscarExercicioPorId(int idExercicio) Exercicio
    }

    class ProgressoRepositorio {
        <<Repository>>
        +buscarPorUsuario(int idUsuario) ProgressoUsuario
        +registrarConclusao(int idUsuario, int idExercicio)
    }

    class SessaoRepositorio {
        <<Repository>>
        +criar(String tokenHash, int idUsuario, Instant expiraEm)
        +buscarIdUsuarioValido(String tokenHash, Instant agora) Integer
        +remover(String tokenHash)
        +removerExpiradas(Instant agora)
    }

    class JdbcTemplate {
        <<Spring JDBC>>
    }

    class Usuario
    class Modulo
    class ProgressoUsuario

    Repositorio <|.. UsuarioRepositorio : T = Usuario
    Repositorio <|.. ModuloRepositorio : T = Modulo

    UsuarioRepositorio ..> Usuario : persiste
    ModuloRepositorio ..> Modulo : persiste (com exercícios)
    ProgressoRepositorio ..> ProgressoUsuario : persiste
    SessaoRepositorio ..> JdbcTemplate
    UsuarioRepositorio --> JdbcTemplate
    ModuloRepositorio --> JdbcTemplate
    ProgressoRepositorio --> JdbcTemplate

    note for Repositorio "CRUD genérico. Só Usuario e Modulo<br/>implementam; Progresso e Sessao têm<br/>API própria, sem a interface."

    style Repositorio fill:#f3e8ff,stroke:#7e22ce,stroke-width:2px,color:#000000
    style UsuarioRepositorio fill:#f3e8ff,stroke:#7e22ce,stroke-width:2px,color:#000000
    style ModuloRepositorio fill:#f3e8ff,stroke:#7e22ce,stroke-width:2px,color:#000000
    style ProgressoRepositorio fill:#f3e8ff,stroke:#7e22ce,stroke-width:2px,color:#000000
    style SessaoRepositorio fill:#f3e8ff,stroke:#7e22ce,stroke-width:2px,color:#000000
    style Usuario fill:#e0f2fe,stroke:#0284c7,stroke-width:2px,color:#000000
    style Modulo fill:#e0f2fe,stroke:#0284c7,stroke-width:2px,color:#000000
    style ProgressoUsuario fill:#e0f2fe,stroke:#0284c7,stroke-width:2px,color:#000000
    style JdbcTemplate fill:#f1f5f9,stroke:#475569,stroke-width:2px,color:#000000
```

## 4. Fluxo de uma resposta (como as camadas colaboram)

```mermaid
sequenceDiagram
    autonumber
    actor Aluno as Frontend (exercicio.js)
    participant Res as ResolvedorUsuarioAutenticado
    participant Ctl as ModuloController
    participant SR as ServicoResposta
    participant MR as ModuloRepositorio
    participant Ex as Exercicio (Multipla Escolha)
    participant UR as UsuarioRepositorio
    participant PR as ProgressoRepositorio
    participant SG as ServicoGamificacao
    participant U as Usuario

    Aluno->>Res: POST + Authorization: Bearer token
    Res->>Res: ServicoAutenticacao.autenticar(token)
    Res-->>Ctl: Usuario autenticado
    Ctl->>SR: responder(usuario, idExercicio, resposta)
    SR->>MR: buscarExercicioPorId(id)
    MR-->>SR: Exercicio
    SR->>Ex: verificarResposta(resposta)
    Ex-->>SR: correta?
    alt resposta errada
        SR-->>Ctl: ResultadoResposta(correta=false, 0 pts)
    else resposta correta (transação)
        SR->>UR: buscarPorIdParaAtualizar(id)  «FOR UPDATE»
        UR-->>SR: Usuario
        SR->>PR: buscarPorUsuario(id)
        PR-->>SR: ProgressoUsuario
        opt exercício ainda não concluído
            SR->>PR: registrarConclusao(idUsuario, idExercicio)
            SR->>SG: processarRespostaCorreta(usuario, exercicio)
            SG->>U: adicionarPontos(pontos) / adicionarXp(pontos)
            SR->>UR: salvar(usuario)
        end
        SR-->>Ctl: ResultadoResposta(correta=true, feedback, pontosGanhos, UsuarioResposta)
    end
    Ctl-->>Aluno: JSON (200)
```

## 5. Padrões de projeto realmente presentes

| Padrão | Onde está | Como as classes interagem | Observação honesta |
|---|---|---|---|
| **Repository** | `Repositorio<T>` (interface genérica); `UsuarioRepositorio` e `ModuloRepositorio` a implementam; `ProgressoRepositorio` e `SessaoRepositorio` seguem o mesmo papel sem a interface | Os `Servico*` só falam com repositórios; só os repositórios conhecem SQL/`JdbcTemplate` e devolvem objetos do Model | Padrão central do projeto. Progresso e Sessão não implementam a interface porque o CRUD genérico não se aplica a eles |
| **Herança + polimorfismo (Strategy por herança)** | `Exercicio.verificarResposta()` (abstrato) → `ExercicioMultiplaEscolha` | `ServicoResposta` chama `exercicio.verificarResposta(...)` sem saber o tipo concreto; cada tipo define sua regra de correção | Hoje há **uma** subclasse; é o ponto de extensão para novos tipos. Não é o Strategy "puro" (a estratégia não é um objeto separado, trocável em tempo de execução) |
| **Singleton (clássico GoF)** | `SessaoUsuario` (construtor privado + `getInstancia()`) | Guarda um `Usuario` em memória | **Não é usado pela API HTTP** (nenhuma classe a referencia). Um usuário global misturaria sessões; a API usa token por usuário (`ServicoAutenticacao` + `SessaoRepositorio`). Mantida por ser parte original do projeto |
| **DTO + Static Factory Method** | pacote `dto` (`records`); `UsuarioResposta.de(...)`, `.comToken(...)`, `ModuloResumoResposta.de(...)`, `ModuloDetalheResposta.de(...)`, `ErroApi.requisicaoInvalida/naoAutenticado/naoEncontrado` | O controller devolve DTOs, nunca entidades; o DTO é montado a partir do Model por fábricas estáticas (ex.: o DTO público do exercício **omite** gabarito e feedback) | Evita vazar `senha` e `indiceCorreto` |
| **Injeção de Dependência (Spring)** | Todos os `@Service`, `@Repository`, `@RestController`, `@Component` recebem dependências pelo construtor | Spring monta o grafo de objetos | Vem do framework; os beans são "singletons do Spring", **não** o Singleton GoF |
| **Agregado (raiz = `Modulo`)** — conceito de DDD | `Modulo` contém `Exercicio`s; `ModuloRepositorio` carrega o conjunto todo | Exercícios só são acessados via módulo (ou `buscarExercicioPorId`) | Conceito de modelagem, não padrão GoF |
| **Extension points do Spring MVC** | `ResolvedorUsuarioAutenticado` (`HandlerMethodArgumentResolver`) + `@UsuarioAutenticado`; `TratadorErros` (`@RestControllerAdvice`); `ConfigWeb` (`WebMvcConfigurer`) | Autenticação e tratamento de erros ficam fora dos controllers, de forma centralizada | Uso de mecanismos do framework, não padrões criados pelo projeto |

**Padrões que NÃO existem no código** (e por isso não aparecem nos diagramas): Facade, Proxy, Chain of Responsibility, Command, Factory/Abstract Factory, Observer, Builder. `ServicoResposta` orquestra vários objetos, mas é um serviço de aplicação, não uma Facade formal.

## 6. Observações sobre MVC e nomenclatura

- **Controller:** `LoginController` e `ModuloController` só recebem a requisição e chamam um serviço (`ModuloController` repassa o `Usuario` autenticado). Nenhuma regra de negócio vive neles. ✔
- **Model:** as regras de pontuação/nível (`Usuario`) e a correção (`Exercicio`) estão no domínio; `ServicoGamificacao` apenas aplica a regra "pontos do exercício = pontos + XP". ✔
- **View:** em API REST a "view" é o JSON; `dto` são records imutáveis sem senha/gabarito. ✔
- **Pontos de atenção (não alterados para preservar o funcionamento):**
  - `SessaoUsuario` está em `util`, mas guarda um `Usuario` (conceito de domínio) e não é usada pela API — é código legado do projeto.
  - `HashSenha` está em `util`, mas funciona como componente de segurança (bean Spring).
  - Convenção de nomes mista: pacotes e `*Controller` em inglês; classes de negócio em português (`Servico*`, `*Repositorio`, `*Resposta`). É consistente dentro de cada grupo; se quiserem padronizar no futuro, o menor impacto é renomear apenas `*Controller` → `*Controlador` (opcional).
  - `Repositorio<T>` só é implementado por 2 dos 4 repositórios (ver seção 5).
