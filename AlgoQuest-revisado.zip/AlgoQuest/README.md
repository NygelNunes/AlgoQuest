# 🎮 AlgoQuest

![Java](https://img.shields.io/badge/Java-ED8B00?style=for-the-badge&logo=java&logoColor=white)
![POO](https://img.shields.io/badge/POO-Arquitetura_Limpa-0284c7?style=for-the-badge)
![Status](https://img.shields.io/badge/Status-Em_Desenvolvimento-15803d?style=for-the-badge)

> Transformando o aprendizado de Algoritmos e Estruturas de Dados em uma experiência gamificada e interativa.

## 📖 Sobre o Projeto

O **AlgoQuest** é um software educacional desenvolvido como projeto acadêmico. 

**O Problema:** Muitos conteúdos relacionados à área de algoritmos (como notação Big O, árvores e tabelas hash) são apresentados de maneira excessivamente teórica e abstrata. Textos longos, fórmulas e exercícios tradicionais muitas vezes não são suficientes para a visualização clara de como as estruturas funcionam.

**A Solução:** O AlgoQuest transforma esses conteúdos em uma experiência dinâmica. O usuário assume o papel de um estudante/desenvolvedor que precisa resolver diferentes desafios computacionais. Em vez de uma prova tradicional, o sistema apresenta problemas contextuais, oferece feedback visual e gamifica o acerto.

---

## 🧠 Estrutura Educacional (Módulos)

O conteúdo é organizado em trilhas de aprendizagem. Os módulos disponíveis (5 módulos × 10 exercícios no banco) são:

*   📊 **Análise de Algoritmos:** Notação Big O (O(1), O(n), O(log n), etc).
*   🔎 **Algoritmos de Busca:** Busca sequencial vs. Busca binária.
*   🔃 **Algoritmos de Ordenação:** Bubble, Selection, Insertion, Merge e Quick Sort.
*   #️⃣ **Tabelas Hash:** Funções, colisões e endereçamento.
*   🌳 **Estruturas de Dados:** Árvores binárias, de busca e balanceamento.

---

## 🎮 A Experiência do Usuário (Gamificação)

A gamificação existe para incentivar, sem tornar o sistema um jogo complexo. O fluxo padrão consiste em:

1. **Escolha do Módulo:** O usuário acessa seu painel e visualiza seu progresso (ex: *Busca: 90% concluído*).
2. **O Desafio:** O sistema apresenta um cenário (ex: *"Você tem 1.000.000 de elementos ordenados. Como achar um valor rapidamente?"*).
3. **Resolução e Feedback:** Após a resposta, o sistema não apenas diz se está certo ou errado, mas fornece uma **explicação educacional**.
4. **Recompensa:** Acertos geram pontos baseados na dificuldade (Fácil: +10, Médio: +20, Difícil: +30) e aumentam o XP/Nível do perfil.

---

## 🏗️ Arquitetura e Modelagem

O AlgoQuest é uma API REST em **Java + Spring Boot** com frontend em HTML/CSS/JS, organizada em camadas **MVC + Service + Repository**. Documento completo: [`docs/ARQUITETURA.md`](docs/ARQUITETURA.md) (diagramas em `docs/diagramas/`).

1. **Model** (`model`): `Usuario`, `Modulo`, `Exercicio` (abstrata) / `ExercicioMultiplaEscolha`, `ProgressoUsuario`, `Dificuldade`.
2. **View**: telas em `frontend/` e a representação JSON da API (`dto`).
3. **Controller** (`controller`): `LoginController`, `ModuloController`.
4. **Service** (`service`): `ServicoAutenticacao`, `ServicoModulo`, `ServicoResposta`, `ServicoGamificacao` — regras de aplicação.
5. **Repository** (`repository`): acesso ao banco por JDBC (H2 ou PostgreSQL) com o padrão *Repository*.
6. **Infraestrutura** (`config`, `exception`, `util`): autenticação por token, tratamento de erros, CORS, hash de senha.

### Visão geral por camadas

![Visão geral por camadas](docs/diagramas/01-visao-geral-camadas.png)

### Diagrama de Classes UML — Model

*(Renderizado automaticamente pelo GitHub.)*

```mermaid
classDiagram
    direction LR

    class Usuario {
        +XP_POR_NIVEL : int = 100
        -int id
        -String nomeUsuario
        -String senha  «hash PBKDF2»
        -int pontuacao
        -int xp
        -int nivel
        +adicionarPontos(int pontos)
        +adicionarXp(int quantidadeXp)
        +subirNivel()
        +getXpProximoNivel() int
    }

    class ProgressoUsuario {
        -int idUsuario
        -List~Integer~ exerciciosConcluidos
        +marcarExercicioConcluido(int idExercicio)
        +isConcluido(int idExercicio) boolean
    }

    class Modulo {
        -int id
        -String titulo
        -String descricao
        -List~Exercicio~ exercicios
        +adicionarExercicio(Exercicio exercicio)
        +getQuantidadeExercicios() int
        +calcularPorcentagem(ProgressoUsuario progresso) double
    }

    class Exercicio {
        <<abstract>>
        -int id
        -String descricao
        -Dificuldade dificuldade
        -int pontos
        -String textoFeedback
        +verificarResposta(Object resposta) boolean*
    }

    class ExercicioMultiplaEscolha {
        -List~String~ opcoes
        -int indiceCorreto
        +verificarResposta(Object resposta) boolean
        -converterIndice(Object resposta) int
    }

    class Dificuldade {
        <<enumeration>>
        FACIL
        MEDIO
        DIFICIL
    }

    Modulo "1" o-- "0..*" Exercicio : contém
    Exercicio <|-- ExercicioMultiplaEscolha : estende
    Exercicio "*" --> "1" Dificuldade
    ProgressoUsuario "0..1" .. "1" Usuario : ligado por idUsuario
    Modulo ..> ProgressoUsuario : calcula % concluída

    note for Modulo "Raiz do agregado: ModuloRepositorio<br/>carrega o módulo com todos os exercícios."
    note for ExercicioMultiplaEscolha "Única subclasse hoje. Cada novo tipo<br/>de exercício implementa sua própria<br/>verificarResposta (ponto de extensão)."
    note for ProgressoUsuario "Referencia o usuário apenas pelo id<br/>(não guarda objeto Usuario)."

    style Usuario fill:#e0f2fe,stroke:#0284c7,stroke-width:2px,color:#000000
    style ProgressoUsuario fill:#e0f2fe,stroke:#0284c7,stroke-width:2px,color:#000000
    style Modulo fill:#e0f2fe,stroke:#0284c7,stroke-width:2px,color:#000000
    style Exercicio fill:#e0f2fe,stroke:#0284c7,stroke-width:2px,color:#000000
    style ExercicioMultiplaEscolha fill:#e0f2fe,stroke:#0284c7,stroke-width:2px,color:#000000
    style Dificuldade fill:#ffedd5,stroke:#c2410c,stroke-width:2px,color:#000000
```

### Padrões de projeto presentes no código

| Padrão | Onde |
|---|---|
| **Repository** | `Repositorio<T>` + `UsuarioRepositorio`, `ModuloRepositorio` (e `ProgressoRepositorio`, `SessaoRepositorio` no mesmo papel) |
| **Herança + polimorfismo (Strategy por herança)** | `Exercicio.verificarResposta()` → `ExercicioMultiplaEscolha` |
| **Singleton** | `SessaoUsuario` — ⚠️ **não é usado pela API HTTP** (a API autentica por token por usuário) |
| **DTO + Static Factory Method** | pacote `dto` (`UsuarioResposta.de(...)`, etc.) e `ErroApi.*` |
| **Injeção de Dependência** | construtores dos `@Service`/`@Repository`/`@RestController` (Spring) |

Detalhes, interações e diagramas de persistência e do fluxo "responder exercício": [`docs/ARQUITETURA.md`](docs/ARQUITETURA.md). Facade, Proxy, Chain of Responsibility e Command **não** existem no código.

---

## 🚀 Próximos Passos & Integração com IA

Nossa estratégia de desenvolvimento será feita em fases. Após garantirmos que o **"Motor" em Java** (classes, lógica, cálculo de pontos) esteja rodando perfeitamente, partiremos para o **Front-end**.

Para a construção da Interface Gráfica e design visual, utilizaremos **Inteligência Artificial** para auxiliar na prototipação das telas, geração de componentes e criação de um futuro "Laboratório de Algoritmos" (para visualização passo a passo do código). 

A ideia é ter um backend robusto e bem padronizado em POO, sustentando um front-end moderno e atraente gerado com auxílio de IA.

---

## 🛠️ Como Contribuir e Executar

1. Faça o clone do repositório:
   ```bash
   git clone https://github.com/SEU_USUARIO/AlgoQuest.git
   ```
2. Abra o projeto na sua IDE favorita (VS Code, IntelliJ, Eclipse).
3. Crie uma branch para sua funcionalidade:
   ```bash
   git checkout -b feature/minha-funcionalidade
   ```
4. Siga as separações de pacotes da arquitetura proposta.
5. Faça o commit e abra um Pull Request!

---

👨‍💻 **Equipe:** Nygel & Antônio


---

## Executando com o backend real (banco + autenticação)

Pré-requisitos: JDK 17+ e Maven. Detalhes e relatório completo: `docs/RELATORIO_INTEGRACAO.md`.

```bash
# 1) Variáveis (veja .env.example). Cria um usuário inicial, pois não há cadastro público:
export ALGOQUEST_USUARIO_INICIAL=seu_usuario
export ALGOQUEST_SENHA_INICIAL='uma-senha-forte-com-8+-caracteres'
# 2) Backend (H2 em ./data por padrão; PostgreSQL via ALGOQUEST_DB_URL/_USUARIO/_SENHA)
mvn spring-boot:run          # API em http://localhost:8080 ; migrações Flyway automáticas
# 3) Frontend: sirva a pasta frontend/ em http://localhost:5500 (ex.: VS Code Live Server ou
#    `cd frontend && python3 -m http.server 5500`). A origem precisa estar em ALGOQUEST_CORS_ORIGENS.
# 4) Testes
mvn test
```

`dev-tools/mock-api/mock-api.py` é apenas um mock de desenvolvimento (não faz parte do backend).

---

## Banco de dados: criar, popular e conectar

O banco tem 5 módulos × 10 exercícios (50 no total, todos de múltipla escolha, pontos Fácil 10 / Médio 20 / Difícil 30).

### Opção A — H2 (padrão, não instala nada)
Basta rodar `mvn spring-boot:run`. O Flyway cria o arquivo `./data/algoquest`, as tabelas e os exercícios (migrações `V1`, `V2`, `V3` em `src/main/resources/db/migration`). Nada a configurar.

### Opção B — PostgreSQL
1. Suba um PostgreSQL: `docker compose up -d` (usa `docker-compose.yml`) **ou** instale o seu e rode
   `psql -U postgres -f database/00_criar_banco_postgresql.sql` (troque a senha do script).
2. Exporte as variáveis (veja `.env.example`):
   ```bash
   export ALGOQUEST_DB_URL=jdbc:postgresql://localhost:5432/algoquest
   export ALGOQUEST_DB_USUARIO=algoquest
   export ALGOQUEST_DB_SENHA=troque-esta-senha
   export ALGOQUEST_USUARIO_INICIAL=seu_usuario
   export ALGOQUEST_SENHA_INICIAL='uma-senha-forte-com-8+-caracteres'
   ```
3. `mvn spring-boot:run`. O Flyway cria as tabelas e popula os exercícios sozinho.

### Scripts SQL avulsos (para rodar à mão, sem Flyway)
Na pasta `database/`, em ordem, conectado ao banco `algoquest`:
`01_esquema.sql` → `02_popular_exercicios.sql` → `validar.sql` (deve listar 5 módulos com 10 exercícios).
**Use só um dos caminhos** (Flyway *ou* scripts à mão) no mesmo banco, senão os dados duplicam.

### Rodar e acessar
1. Backend: `mvn spring-boot:run` (http://localhost:8080).
2. Frontend: `cd frontend && python3 -m http.server 5500` e abra http://localhost:5500.
3. Entre com o usuário definido em `ALGOQUEST_USUARIO_INICIAL` — os módulos e exercícios vêm do banco.

Para editar/gerar mais exercícios: `tools/gerar_v3.py` mostra o formato; novas mudanças devem virar uma migração nova (`V4__...sql`), sem alterar V1–V3.
