# AlgoQuest — Grimório Vivo: Implementation Report & Technical Handoff

Everything in sections 1–7 describes what was **actually built and verified** in this session. Section 8 lists what was **only proposed and NOT built**. Sections 9–10 contain the exact diffs and the complete source of every new file, generated directly from the delivered project (so they cannot drift from the code).

## 1. Diagnosis (what I found in the original ZIP)

- **Stack:** Java + Spring Boot REST API (`src/main/java/algoquest/...`: controller → service → repository over JDBC, H2/PostgreSQL, Flyway migrations V1–V3) + a framework-free frontend in `frontend/` (static HTML/CSS/vanilla JS, no build step). `dev-tools/mock-api/mock-api.py` serves the frontend on :5500 and a fake API on :8080.
- **Domain:** `Modulo` → `Exercicio` (abstract, `verificarResposta`) → `ExercicioMultiplaEscolha` (the only subclass). 5 modules × 10 multiple-choice questions, points by difficulty (10/20/30), XP/level server-side.
- **Frontend flow:** `index.html` (login) → `modulos.html` (hero + module cards/map) → `exercicio.html?modulo=ID` (one question at a time). Shared shell in `js/ui.js` (menu, character panel), art in `js/arte.js`, design system in `css/style.css` (dark/steel/crimson/gold, Cinzel + Cormorant + Inter fonts, circuit/noise textures).
- **Main weakness (confirmed, matches the brief):** the product teaches Data Structures & Algorithms but every exercise is text-only multiple choice. The RPG skin (hexes, map, XP) is cosmetic; nothing in the *learning* is spatial, temporal or manipulable. The architecture anticipates more (abstract `Exercicio`, "each new type implements its own `verificarResposta`") but only one type exists.

## 2. Product decision

Instead of adding many shallow features, I attacked the one gap that defines the product's identity: **you can't see the algorithms run.** The result is the **Grimório Vivo** ("Living Grimoire"): an in-world spellbook where each algorithm is a spell executed step by step in front of the player, with two ways to engage beyond reading:

1. **Modo Desafio — "predict the next step".** Before a step is revealed the player must commit to a prediction (swap or keep? left or right? which bucket? *which AVL rotation?*). Correct predictions build a per-simulator **mastery rank** (Noviço → Adepto → Mestre). This is where the RPG layer becomes real gameplay: rank is earned by demonstrated understanding of the mechanism, not by memorizing answers.
2. **Ordenar à mão (Bubble Sort).** The player sorts the bars manually using adjacent swaps only, and is told the minimum possible (= number of inversions), teaching *why* Bubble Sort does exactly that many swaps.

Design constraints respected: frontend-only (zero backend changes), no build tooling, reuses the existing design tokens/components (`.superficie`, `.opcao`, `.feedback`, `.btn`, `.hex`), all learner-facing text in pt-BR, mature tone (no mascots/cartoon), `prefers-reduced-motion` honored.

## 3. What was implemented (all verified — see section 7)

| # | Feature | Status |
|---|---|---|
| 1 | New page `laboratorio.html` ("Grimório Vivo") with 5 simulators: **Bubble Sort, Busca Binária, Tabela Hash (chaining), BST, AVL** | Done |
| 2 | Step player: play/pause, step back/forward, jump to start, timeline scrubber, 4 speeds, keyboard ←/→ | Done |
| 3 | Editable inputs per simulator with pt-BR validation + "Sortear dados" (random data) | Done |
| 4 | Animated visuals: bars slide on swap; tree nodes **tween to new positions** so rotations are visible; AVL shows balance factors (red when |fb|>1); highlighted search path; hash collisions turn crimson | Done |
| 5 | Pt-BR narration for every step, including the *reason* (e.g. LL/RR/LR/RL case explanation) and complexity facts | Done |
| 6 | **Modo Desafio** with question + instant explanation + per-session score/streak | Done |
| 7 | **Mastery ranks** (3 pips per simulator, shown on tabs and scoreboard), persisted in `localStorage` per username | Done (browser-local only) |
| 8 | **Ordenar à mão** mode (Bubble Sort) with inversion-count feedback | Done |
| 9 | Menu item "Grimório Vivo" (active state aware) and an invitation card on `modulos.html` | Done |
| 10 | **"Ver na prática"** button inside exercises: embeds the matching simulator (`?embed=1` iframe, chromeless). Matching is by question text first, module theme second. Verified against all 50 seeded questions: 25 get a simulator (Bubble, Busca Binária, Hash, BST); the rest (generic Big O, Merge/Quick sort, etc.) correctly get no button | Done |
| 11 | Logic test suite (Node) + optional Playwright E2E | Done |

## 4. Architecture of the addition

```
frontend/js/lab-sims.js   PURE logic (no DOM). SIMS catalog: each simulator = {titulo, campos, ler(form), aleatorio(), gerar(entrada) -> passos[]}.
                          A "passo" is a snapshot + pt-BR `txt`; if it has `pergunta` {enunciado, opcoes, certa, explica}, Challenge mode asks BEFORE revealing it.
                          Exposed as window.AQSims and module.exports (Node-testable).
frontend/js/lab.js        UI: tabs, form, player, renderers R.bubble/R.busca/R.hash/R.bst/R.avl, tree layout+tween, challenge flow, mastery, manual mode.
frontend/css/lab.css      Styles (loaded after style.css). Reuses its tokens. `body.lab-embed` hides menu/profile for the iframe.
frontend/laboratorio.html Page shell (same grid as modulos.html: #menu / #conteudo / #perfil).
```

Key technical decisions:
- **Steps are precomputed**, not simulated live. That makes back/forward/scrub trivial and keeps rendering a pure function of one snapshot. Trees are deep-cloned per step (inputs are capped at 12 nodes, so cost is negligible).
- **Question attaches to the step that *reveals* the result**, so the preceding step always shows the situation needed to answer (e.g. the compared pair, the middle element, the current node).
- **Tree layout** = in-order x index, depth y. Positions are keyed by node value and interpolated for ~520 ms between steps (`requestAnimationFrame`; disabled under `prefers-reduced-motion`). That interpolation is what makes rotations legible.
- **Bubble bars** are DOM nodes with stable ids positioned by CSS `left: calc(var(--i) * 100% / var(--n))` with a transition, so swaps animate for free.
- **Class-name collision avoided:** `style.css` already defines `.pips` (rotated diamonds for difficulty). The mastery bar uses `.maes` instead; do not rename it back.
- **No change to scoring/XP/backend.** "Ver na prática" is presentation only; Challenge results never touch the API.

## 5. Dependencies & configuration

- **None added.** No npm/Maven changes, no new fonts/icons (reuses `i-book-open`, `i-swords`, etc. already in `assets.css`).
- Optional dev-only: Node ≥ 18 for the logic tests; `pip install playwright && playwright install chromium` for the E2E script.
- Storage keys (browser-local): `aq_maestria_<nomeUsuario>` in `localStorage` — `{ "<simId>": {a: hits, t: total, seq: streak, melhor: best streak} }`.
- URL parameters of `laboratorio.html`: `sim=bubble|busca|hash|bst|avl`, `embed=1`.

## 6. Integration instructions (applying to the original ZIP)

1. Copy the 6 new files (section 10) to the exact paths shown.
2. Apply the diffs for the 5 modified files (section 9) — they are small and independent (`patch -p0` style hunks are standard unified diffs; paths are relative to the project root).
3. No backend, SQL or `pom.xml` changes are needed.
4. Run (from the project root, which contains `frontend/`):
   ```bash
   node dev-tools/testes/lab-sims.test.js          # expects: 6 grupos de teste passaram
   python3 dev-tools/mock-api/mock-api.py          # frontend :5500, mock API :8080
   # open http://127.0.0.1:5500/index.html, log in with any user (mock accepts any password except "errada"), then open "Grimório Vivo" in the menu
   python3 dev-tools/testes/e2e_lab.py             # optional; needs playwright; prints "ERROS: nenhum"
   ```
5. With the real Spring backend, serve `frontend/` however it is served today; the Grimório needs no new endpoints.

## 7. Verification actually performed

- **Logic tests (Node):** Bubble sorts correctly over 50 random inputs and stops early on sorted input; binary search finds/doesn't find; hash position == `k mod m` and collision counts; BST invariant + in-order == sorted over 50 random inputs; **AVL keeps |balance factor| ≤ 1 at every post-rotation snapshot and at the end over 200 random inputs**, and the canonical sequences produce the expected rotation (`10,20,30,40,50,25` → simples-esquerda ×2 then dupla direita-esquerda; `3,2,1` → simples-direita; `30,10,20` → dupla esquerda-direita); every `pergunta.certa` is a valid option index; input validation messages.
- **Browser E2E (Chromium via Playwright, mock API):** all 5 simulators run to the last step; Challenge mode answered through a full AVL run with score/mastery persisted; manual-sort mode; invalid input error; exercise page opens the embedded simulator; **zero console/page errors**. Layouts reviewed by screenshot at 1440 px and 390 px.
- **Bugs found and fixed during verification (so you don't re-introduce them):** (a) recursion with a shadowed variable in the tree drawer; (b) `.pips` CSS collision (see above); (c) default Hash sample put every key in one bucket (all ≡ 1 mod 7) — replaced with `15, 22, 9, 36, 12, 25, 41`; (d) the "binária" regex matched *"árvore binária"* and sent 6 tree questions to the binary-search simulator — now `/busca bin[áa]ria/`; (e) the active tab was off-screen on mobile — the tab strip now centers it.

## 8. Pending / NOT done / limitations (explicit)

Not implemented (only ideas — do **not** treat as existing):
- **Server-side persistence of mastery and any XP/points for Challenge answers.** Today mastery is `localStorage` only (labelled as such in the UI). Doing it properly needs a new endpoint + table (e.g. `maestria_simulador(usuario_id, sim, acertos, total, melhor_sequencia)`) and a decision on whether Challenge hits grant XP (risk: XP farming by re-running the same sequence; mitigate by capping per-day or per-input-hash).
- **New exercise type with server-verified interactive answers** (e.g. `ExercicioInterativo` subclass of `Exercicio` implementing `verificarResposta`, so "insert these keys into an AVL — what is the root?" is graded by the API instead of the browser). The existing OO design anticipates this; not built.
- **Audio** (ambient/SFX), **avatars/customization/character classes**, **quest chains / narrative framing of modules**, **daily challenge / streaks across days**.
- More simulators: Selection/Insertion/Merge/Quick Sort, tree deletion, open-addressing hash, Big-O growth plotter.

Known limitations:
- The **AVL simulator is not linked from any seeded exercise** (no seeded question mentions AVL/rotations); it is reachable from the menu/tabs. The linker already routes AVL/rotation questions to it if such questions are added.
- Tested only against the **mock API** and only in **Chromium**; the Spring backend and Java tests were not run (and were not modified).
- Inputs are capped (Bubble ≤10, Search ≤16, Hash/trees ≤12, values 1–99) to keep visuals legible.
- Challenge mode lets a wrong answer through (it shows the correct option + explanation and moves on; no retry). Re-running the same input can be used to farm mastery locally — acceptable while it is only a local, cosmetic rank.
- The Grimório page does not yet reflect mastery in the character panel (`#perfil`).
- Question text routing for "Ver na prática" is keyword-based (`simuladorDo` in `exercicio.js`); adding a `simulador` column to `exercicio` would be the robust version.

## 9. Diffs of modified files (generated against the original ZIP)

### `frontend/js/ui.js`

```diff
--- a/frontend/js/ui.js
+++ b/frontend/js/ui.js
@@ -30,10 +30,12 @@
 function montarMenu() {
   const m = document.getElementById("menu");
   if (!m) return;
+  const noLab = /laboratorio\.html$/.test(location.pathname);
   m.className = "menu superficie";
   m.innerHTML = `<a class="marca" href="modulos.html" aria-label="AlgoQuest">Algo<b>Quest</b></a>
     <nav class="menu__nav" aria-label="Principal">
-      <a class="menu__item is-ativo" href="modulos.html" aria-current="page" title="Central de Desafios">${ic("swords")}<span>Central de Desafios</span></a>
+      <a class="menu__item${noLab ? "" : " is-ativo"}" href="modulos.html"${noLab ? "" : ' aria-current="page"'} title="Central de Desafios">${ic("swords")}<span>Central de Desafios</span></a>
+      <a class="menu__item${noLab ? " is-ativo" : ""}" href="laboratorio.html"${noLab ? ' aria-current="page"' : ""} title="Grimório Vivo">${ic("book-open")}<span>Grimório Vivo</span></a>
     </nav>
     <p class="menu__lema">Aprenda. Evolua. Conquiste.</p>
     <button class="menu__sair" id="btnSair" type="button" aria-label="Sair" title="Sair">${ic("log-out")}<span>Sair</span></button>`;
```

### `frontend/js/exercicio.js`

```diff
--- a/frontend/js/exercicio.js
+++ b/frontend/js/exercicio.js
@@ -18,6 +18,35 @@
   c.classList.remove("entra"); void c.offsetWidth; c.classList.add("entra");
 }
 
+
+// "Ver na pratica": liga o exercicio ao simulador do Grimorio Vivo (iframe em modo incorporado). So apresentacao: nao afeta a resposta nem a pontuacao.
+function simuladorDo(ex, tema) {
+  // Prioridade: o que a PERGUNTA menciona; so depois o tema do modulo.
+  const t = (ex.descricao || "").toLowerCase();
+  if (/avl|rota[cç]|balancead/.test(t)) return "avl";
+  if (/bubble|bolha|adjacentes|subirem/.test(t)) return "bubble";
+  if (/busca bin[áa]ria/.test(t)) return "busca";
+  if (/hash|coli[sz]|encadeamento/.test(t)) return "hash";
+  if (/[áa]rvore|\bbst\b|em-ordem|in-order|percurso/.test(t)) return "bst";
+  if (tema === "hash") return "hash";
+  if (tema === "arvore") return "bst";
+  return null; // ordenacao (exceto Bubble), busca sequencial e Big O gerais nao tem simulador dedicado
+}
+function painelPratica(ex) {
+  const alvo = $("vernapratica"), sim = simuladorDo(ex, temaDe(tituloModulo));
+  alvo.innerHTML = ""; alvo.hidden = !sim;
+  if (!sim) return;
+  const url = "laboratorio.html?sim=" + sim;
+  alvo.innerHTML = `<div class="vernapratica__cab"><button class="btn btn--fantasma" id="btnPratica" type="button" aria-expanded="false">${ic("book-open")}<span>Ver na prática</span></button>
+    <span class="dica">Execute este conceito passo a passo no Grimório Vivo antes de responder.</span></div><div id="praticaCorpo" hidden></div>`;
+  $("btnPratica").addEventListener("click", () => {
+    const corpo = $("praticaCorpo"), abrir = corpo.hidden;
+    corpo.hidden = !abrir; $("btnPratica").setAttribute("aria-expanded", String(abrir));
+    $("btnPratica").querySelector("span").textContent = abrir ? "Fechar simulação" : "Ver na prática";
+    if (abrir && !corpo.firstChild) corpo.innerHTML = `<iframe title="Simulação no Grimório Vivo" src="${url}&embed=1" loading="lazy"></iframe><p class="dica"><a href="${url}">Abrir em tela cheia</a></p>`;
+  });
+}
+
 function renderizarExercicio(ex) {
   const total = exercicios.length;
   $("feedback").hidden = true;
@@ -37,6 +66,7 @@
   $("opcoes").innerHTML = (ex.opcoes || []).map((o, i) =>
     `<button class="opcao" type="button" data-i="${i}" style="--k:${i}"><span class="opcao__letra">${String.fromCharCode(65 + i)}</span><span class="opcao__texto">${esc(o)}</span></button>`).join("");
   entrada();
+  painelPratica(ex);
   document.querySelectorAll(".opcao").forEach((btn) =>
     btn.addEventListener("click", async () => {
       if (btn.classList.contains("errada")) return;
```

### `frontend/exercicio.html`

```diff
--- a/frontend/exercicio.html
+++ b/frontend/exercicio.html
@@ -1,5 +1,5 @@
 <!DOCTYPE html>
-<html lang="pt-BR"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"><meta name="theme-color" content="#07080b"><link rel="stylesheet" href="css/assets.css"><link rel="stylesheet" href="css/style.css"><title>AlgoQuest - Exercício</title></head>
+<html lang="pt-BR"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"><meta name="theme-color" content="#07080b"><link rel="stylesheet" href="css/assets.css"><link rel="stylesheet" href="css/style.css"><link rel="stylesheet" href="css/lab.css"><title>AlgoQuest - Exercício</title></head>
 <body class="pagina-app" data-perfil="compacto">
   <div class="app app--foco">
     <aside id="menu"></aside>
@@ -16,6 +16,7 @@
         <div class="desafio__corpo" id="corpo">
           <div class="pergunta"><h2 id="descricao">Carregando exercício...</h2></div>
           <div class="opcoes" id="opcoes"></div>
+          <div class="vernapratica" id="vernapratica" hidden></div>
           <p class="feedback" id="feedback" role="status" hidden></p>
         </div>
         <div class="acoes"><button class="btn btn--fantasma" id="btnAnterior" type="button" hidden>Anterior</button>
```

### `frontend/modulos.html`

```diff
--- a/frontend/modulos.html
+++ b/frontend/modulos.html
@@ -1,5 +1,5 @@
 <!DOCTYPE html>
-<html lang="pt-BR"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"><meta name="theme-color" content="#07080b"><link rel="stylesheet" href="css/assets.css"><link rel="stylesheet" href="css/style.css"><title>AlgoQuest - Módulos</title></head>
+<html lang="pt-BR"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"><meta name="theme-color" content="#07080b"><link rel="stylesheet" href="css/assets.css"><link rel="stylesheet" href="css/style.css"><link rel="stylesheet" href="css/lab.css"><title>AlgoQuest - Módulos</title></head>
 <body class="pagina-app">
   <div class="app">
     <aside id="menu"></aside>
@@ -13,6 +13,11 @@
         </div>
         <dl class="visao" id="visaoGeral"></dl>
       </section>
+      <a class="convite superficie" href="laboratorio.html" aria-label="Abrir o Grimório Vivo">
+        <span class="hex"><i class="ic i-book-open" aria-hidden="true"></i></span>
+        <span class="convite__txt"><b>Grimório Vivo</b><span>Veja ordenação, busca, hash e árvores AVL em ação — passo a passo, com rotações animadas e um modo para apostar no próximo movimento.</span></span>
+        <span class="btn btn--fantasma">Abrir o Grimório <i class="ic i-arrow-right" aria-hidden="true"></i></span>
+      </a>
       <section aria-labelledby="tituloCentral">
         <div class="secao__titulo"><h2 id="tituloCentral"><i class="ic i-scroll-text" aria-hidden="true"></i>Central de Desafios</h2>
           <div class="alterna" id="alterna" role="group" aria-label="Modo de visualização">
```

### `README.md`

```diff
--- a/README.md
+++ b/README.md
@@ -16,6 +16,12 @@
 
 ---
 
+## 🔮 Grimório Vivo (simuladores visuais)
+
+Página `frontend/laboratorio.html` com simulações **passo a passo, em português**: Bubble Sort, Busca Binária, Tabela Hash (encadeamento), Árvore Binária de Busca e Árvore AVL (fatores de balanceamento e rotações animadas). Recursos: reproduzir/pausar/voltar/linha do tempo, dados editáveis, **Modo Desafio** (preveja o próximo passo para ganhar maestria — Noviço, Adepto, Mestre) e **ordenar à mão** (Bubble Sort). Nos exercícios, o botão **Ver na prática** abre o simulador correspondente. Frontend puro (sem build); a maestria fica no `localStorage`. Detalhes técnicos: [`docs/IMPLEMENTACAO_GRIMORIO.md`](docs/IMPLEMENTACAO_GRIMORIO.md). Testes: `node dev-tools/testes/lab-sims.test.js`.
+
+---
+
 ## 🧠 Estrutura Educacional (Módulos)
 
 O conteúdo é organizado em trilhas de aprendizagem. Os módulos disponíveis (5 módulos × 10 exercícios no banco) são:
```

## 10. Complete source of new files

### `frontend/laboratorio.html` (51 lines, NEW)

```html
<!DOCTYPE html>
<html lang="pt-BR"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"><meta name="theme-color" content="#07080b"><link rel="stylesheet" href="css/assets.css"><link rel="stylesheet" href="css/style.css"><link rel="stylesheet" href="css/lab.css"><title>AlgoQuest - Grimório Vivo</title></head>
<body class="pagina-app">
  <div class="app">
    <aside id="menu"></aside>
    <main class="conteudo" id="conteudo">
      <section class="lab superficie" aria-labelledby="labTitulo">
        <header class="lab__topo">
          <div>
            <h1 id="labTitulo"><i class="ic i-book-open" aria-hidden="true"></i>Grimório Vivo</h1>
            <p class="lore">Cada feitiço da computação, executado diante dos seus olhos. Avance passo a passo — ou aposte no próximo movimento.</p>
          </div>
        </header>
        <div class="lab__abas" id="abas" role="tablist" aria-label="Simulações"></div>

        <div class="lab__intro"><h2 id="simTitulo"></h2><p id="simResumo"></p><p class="lab__fato" id="simFato"></p></div>

        <form class="lab__entrada" id="entrada" novalidate>
          <div class="lab__campos" id="campos"></div>
          <div class="lab__botoes">
            <button class="btn btn--primario" type="submit">Executar</button>
            <button class="btn btn--fantasma" type="button" id="btnAleatorio">Sortear dados</button>
            <button class="btn btn--fantasma" type="button" id="btnManual" hidden>Ordenar à mão</button>
          </div>
          <p class="lab__erro" id="erroEntrada" role="alert" hidden></p>
        </form>

        <div class="lab__palco" id="palco" aria-label="Visualização da simulação"></div>
        <p class="lab__narra" id="narra" role="status" aria-live="polite"></p>

        <div class="lab__pergunta" id="pergunta" hidden aria-live="polite"></div>

        <div class="lab__controles" id="controles">
          <div class="lab__transporte">
            <button class="btn btn--fantasma btn--icone" id="btnInicio" type="button" aria-label="Voltar ao início" title="Início"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 5v14M19 5L9 12l10 7z"/></svg></button>
            <button class="btn btn--fantasma btn--icone" id="btnAnt" type="button" aria-label="Passo anterior" title="Passo anterior"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M15 5l-7 7 7 7"/></svg></button>
            <button class="btn btn--primario btn--icone" id="btnPlay" type="button" aria-label="Reproduzir" title="Reproduzir"><svg viewBox="0 0 24 24" aria-hidden="true"><path class="p-play" d="M8 5l11 7-11 7z"/><path class="p-pause" d="M8 5v14M16 5v14"/></svg></button>
            <button class="btn btn--fantasma btn--icone" id="btnProx" type="button" aria-label="Próximo passo" title="Próximo passo"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 5l7 7-7 7"/></svg></button>
          </div>
          <label class="lab__vel"><span>Velocidade</span><input id="velocidade" type="range" min="1" max="4" step="1" value="2"></label>
          <label class="lab__passo"><span id="passoRotulo">Passo 1 de 1</span><input id="linha" type="range" min="0" max="0" value="0" aria-label="Linha do tempo da simulação"></label>
          <button class="lab__desafio" id="btnDesafio" type="button" aria-pressed="false"><i class="ic i-swords" aria-hidden="true"></i><span>Modo Desafio</span></button>
        </div>

        <div class="lab__placar" id="placar" aria-label="Maestria"></div>
      </section>
    </main>
    <aside id="perfil" aria-label="Personagem"></aside>
  </div>
  <script src="js/api.js"></script><script src="js/arte.js"></script><script src="js/ui.js"></script><script src="js/lab-sims.js"></script><script src="js/lab.js"></script>
</body></html>
```

### `frontend/css/lab.css` (144 lines, NEW)

```css
/* AlgoQuest — Grimório Vivo (simuladores). Reutiliza os tokens de style.css; carregar DEPOIS dele. */
.lab{--tom:var(--crimson-hi);display:grid;gap:var(--s5);padding:var(--s5) var(--s6)}
.lab__topo h1{display:flex;align-items:center;gap:var(--s3);font-size:clamp(1.4rem,2.2vw,1.8rem)}
.lab__topo h1 .ic{color:var(--gold)}
.lab__topo .lore{margin-top:var(--s2);font:italic 500 1.2rem/1.4 var(--f-lore);color:var(--muted);max-width:60ch}

/* abas */
.lab__abas{display:flex;gap:var(--s2);overflow-x:auto;padding-bottom:var(--s2);scrollbar-width:thin;scrollbar-color:var(--steel) transparent}
.lab__abas button{--tom:var(--steel);display:flex;align-items:center;gap:var(--s3);flex:none;min-height:56px;padding:var(--s2) var(--s4) var(--s2) var(--s2);background:linear-gradient(180deg,#12161d,var(--surface));border:1px solid var(--line);border-radius:var(--r);cursor:pointer;color:var(--muted);text-align:left;transition:border-color .2s,color .2s,background .2s}
.lab__abas button .hex{width:2.4rem;height:2.4rem;font-size:1rem}
.lab__abas button:hover{color:var(--text);border-color:var(--gold)}
.lab__abas button[aria-selected=true]{color:var(--text);border-color:var(--tom);background:linear-gradient(90deg,var(--blood),var(--surface));box-shadow:inset 0 -2px 0 var(--tom)}
.aba__txt{display:grid;gap:2px}.aba__txt b{font:600 .85rem var(--f-head);letter-spacing:.03em;white-space:nowrap}
.maes{display:inline-flex;gap:3px;align-items:center}.maes i{display:block;width:12px;height:4px;border-radius:2px;background:var(--line);border:0;transform:none}.maes i.on{background:var(--gold-hi);box-shadow:0 0 6px #dcc08488}
.maes--grande i{width:20px;height:6px}

/* introducao + entrada */
.lab__intro{display:grid;gap:var(--s2)}
.lab__intro h2{font-size:1.25rem;color:var(--gold)}
.lab__fato{font-size:.85rem;color:var(--silver);padding-left:var(--s3);border-left:2px solid var(--tom)}
.lab__entrada{display:grid;gap:var(--s3)}
.lab__campos{display:flex;flex-wrap:wrap;gap:var(--s3)}
.campo{display:grid;gap:var(--s1);flex:1 1 280px;font-size:.8rem;color:var(--muted)}
.campo--curto{flex:0 1 160px}
.campo input{min-height:44px;padding:0 var(--s3);background:#050608;border:1px solid var(--line);border-radius:var(--r);font:500 .95rem var(--f-ui);color:var(--text);transition:border-color .2s}
.campo input:focus{border-color:var(--gold);outline:none;box-shadow:0 0 0 2px #b89a5e33}
.lab__botoes{display:flex;flex-wrap:wrap;gap:var(--s2)}
.lab__erro{color:#f4cdd0;font-size:.88rem;padding:var(--s2) var(--s3);border:1px solid #a3212b88;background:#3a0d1277;border-radius:var(--r)}

/* palco */
.lab__palco{position:relative;min-height:260px;padding:var(--s4);border:1px solid var(--line);border-radius:var(--r);background:var(--grade),radial-gradient(500px 220px at 50% 0,#1a2029,#080a0e);overflow:hidden}

/* bubble */
.barras{position:relative;height:250px;width:100%}
.barra{position:absolute;bottom:0;height:100%;width:calc(100% / var(--n));left:calc(var(--i) * 100% / var(--n));padding:0 4px;display:flex;align-items:flex-end;transition:left .42s cubic-bezier(.3,.7,.2,1)}
.barra__col{width:100%;display:flex;justify-content:center;align-items:flex-start;border-radius:3px 3px 0 0;background:linear-gradient(180deg,#59626f,#2a313c);border:1px solid var(--steel);border-bottom:0;transition:background .25s,border-color .25s,box-shadow .25s}
.barra__col b{margin-top:6px;font:600 .85rem var(--f-head);color:var(--text)}
.barra--cmp .barra__col{background:linear-gradient(180deg,var(--gold-hi),#7a6232);border-color:var(--gold-hi);box-shadow:0 0 18px #dcc08455}
.barra--cmp .barra__col b{color:#17120a}
.barra--troca .barra__col{background:linear-gradient(180deg,var(--crimson-hi),#6e1219);border-color:#e0646c;box-shadow:0 0 18px #d0343e66}
.barra--ok .barra__col{background:linear-gradient(180deg,#4fb06c,#1f5a33);border-color:var(--moss)}
.lab--manual .barra{cursor:pointer}.lab--manual .barra:hover .barra__col{border-color:var(--gold)}
.lab--manual .barra:focus-visible{outline:2px solid var(--gold-hi);outline-offset:-2px}

/* busca */
.celulas{display:grid;grid-template-columns:repeat(var(--n),minmax(0,1fr));gap:4px;align-items:end;min-height:200px;padding-top:var(--s4)}
.cel{display:grid;justify-items:center;gap:6px;transition:opacity .3s}
.cel__marca{min-height:2.2em;font-size:.68rem;line-height:1.1;text-align:center;color:var(--gold-hi);text-transform:uppercase;letter-spacing:.04em}
.cel__v{display:grid;place-items:center;width:100%;aspect-ratio:1/1.1;max-width:64px;border:1px solid var(--steel);border-radius:var(--r);background:linear-gradient(180deg,#1a2029,var(--surface));font:600 clamp(.8rem,1.4vw,1.05rem) var(--f-head);transition:background .25s,border-color .25s,box-shadow .25s}
.cel__i{font-size:.72rem;color:var(--muted)}
.cel--fora{opacity:.28}
.cel--meio .cel__v{border-color:var(--gold-hi);background:linear-gradient(180deg,#4a3d20,#1f1a0e);box-shadow:0 0 18px #dcc08455}
.cel--achou .cel__v{border-color:var(--moss);background:linear-gradient(180deg,#1f5a33,#0e2a18);box-shadow:0 0 20px #3f9a5a77}

/* hash */
.hashtab{display:grid;gap:6px}
.hl{display:flex;align-items:center;gap:var(--s3);min-height:40px;padding:2px var(--s2);border:1px solid var(--line);border-radius:var(--r);background:#0b0e13;transition:border-color .25s,background .25s}
.hl__i{display:grid;place-items:center;flex:none;width:2.2rem;height:2.2rem;border:1px solid var(--steel);border-radius:var(--r);font:600 .85rem var(--f-head);color:var(--silver)}
.hl__cadeia{display:flex;align-items:center;gap:6px;flex-wrap:wrap}
.chave{display:inline-grid;place-items:center;min-width:2.4rem;height:2rem;padding:0 8px;border:1px solid var(--gold);border-radius:var(--r);background:#1d1a10;font:600 .85rem var(--f-head);color:var(--gold-hi)}
.chave--nova{animation:acerto .7s ease-out;border-color:var(--moss);background:#10261788;color:#c4e8cf}
.seta{color:var(--muted);font-style:normal}
.vazio{font-size:.78rem;color:#5a6270;font-style:italic}
.hl--alvo{border-color:var(--gold-hi);background:linear-gradient(90deg,#2b2412,#0b0e13)}
.hl--colisao{border-color:var(--crimson-hi);background:linear-gradient(90deg,#3a0d12,#0b0e13)}
.hl--colisao .chave--nova{border-color:var(--crimson-hi);background:#3a0d12;color:#f4cdd0}
.hashtab__chave{margin-top:var(--s3);color:var(--muted);font-size:.9rem}.hashtab__chave b{color:var(--gold-hi);font-family:var(--f-head)}

/* arvores */
.arv{display:block;width:100%;height:auto;margin:0 auto}
.arv .ar{stroke:var(--steel);stroke-width:2}
.arv .ar--cam{stroke:var(--gold);stroke-width:2.5}
.noarv circle{fill:#151a22;stroke:var(--silver);stroke-width:2;transition:fill .2s,stroke .2s}
.noarv text{fill:var(--text);font:600 13px var(--f-head)}
.noarv .fb{fill:var(--silver);font:600 11px var(--f-ui)}
.noarv .fb--mau{fill:#ff8d95}
.no--cam circle{stroke:var(--gold)}
.no--atual circle{fill:#4a3d20;stroke:var(--gold-hi);filter:drop-shadow(0 0 8px #dcc084aa)}
.no--novo circle{fill:#1f5a33;stroke:var(--moss);filter:drop-shadow(0 0 8px #3f9a5aaa)}
.no--ruim circle{fill:#5a1219;stroke:var(--crimson-hi);filter:drop-shadow(0 0 9px #d0343eaa)}
.no--girou circle{fill:#1d3a52;stroke:#6f8fb5;filter:drop-shadow(0 0 8px #6f8fb5aa)}

/* narracao + pergunta */
.lab__narra{min-height:3.4em;padding:var(--s4);border-left:2px solid var(--tom);background:var(--grade),linear-gradient(90deg,#ffffff08,transparent);border-radius:0 var(--r) var(--r) 0;font-size:1.02rem;line-height:1.6}
.lab__pergunta{display:grid;gap:var(--s3);padding:var(--s4);border:1px solid var(--crimson);border-radius:var(--r);background:linear-gradient(180deg,#2a0b10,#12090b);animation:troca .35s both}
.lab__pergunta-tit{display:flex;align-items:center;gap:var(--s2);font:600 .8rem var(--f-head);letter-spacing:.08em;text-transform:uppercase;color:var(--crimson-hi)}
.lab__pergunta-txt{font-size:1.05rem}
.lab__opcoes{display:grid;gap:var(--s2);grid-template-columns:repeat(auto-fit,minmax(220px,1fr))}
.lab__opcoes .opcao{min-height:52px}

/* controles */
.lab__controles{display:flex;flex-wrap:wrap;align-items:center;gap:var(--s4)}
.lab__transporte{display:flex;gap:var(--s2)}
.btn--icone{width:48px;padding:0}
.btn--icone svg{width:20px;height:20px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
.btn--icone svg .p-play{fill:currentColor;stroke:none}.btn--icone svg .p-pause{display:none}
.tocando #btnPlay .p-play{display:none}.tocando #btnPlay .p-pause{display:block}
.lab__vel,.lab__passo{display:grid;gap:2px;font-size:.78rem;color:var(--muted)}
.lab__passo{flex:1 1 220px}
.lab input[type=range]{width:100%;accent-color:var(--crimson-hi);min-height:28px;cursor:pointer}
.lab input[type=range]:disabled{opacity:.4;cursor:not-allowed}
.lab__vel{flex:0 1 140px}
.lab__desafio{display:inline-flex;align-items:center;gap:var(--s2);min-height:44px;padding:0 var(--s4);background:#ffffff06;border:1px solid var(--steel);border-radius:var(--r);cursor:pointer;font:600 .88rem var(--f-ui);color:var(--text);transition:border-color .2s,background .2s,box-shadow .2s}
.lab__desafio:hover{border-color:var(--gold)}
.lab__desafio[aria-pressed=true]{background:var(--blood);border-color:var(--crimson-hi);box-shadow:inset 0 -2px 0 var(--crimson-hi),0 0 18px #a3212b55}
.lab--manual .lab__controles{display:none}

/* placar */
.lab__placar{display:grid;gap:var(--s2);padding-top:var(--s4);border-top:1px solid var(--line);font-size:.9rem}
.placar__nivel{display:flex;align-items:center;gap:var(--s3)}
.placar__nivel b{font-family:var(--f-head);color:var(--gold-hi)}
.placar__sessao{color:var(--silver)}
.placar__nota{font-size:.75rem}

/* convite na Central de Desafios */
.convite{display:flex;align-items:center;gap:var(--s4);flex-wrap:wrap;padding:var(--s4) var(--s5);border-left:3px solid var(--gold)}
.convite .hex{--tom:var(--gold)}
.convite__txt{flex:1 1 260px;display:grid;gap:2px}
.convite__txt b{font:600 1.05rem var(--f-head);color:var(--gold-hi)}
.convite__txt span{color:var(--muted);font-size:.9rem}

/* painel "Ver na pratica" dentro do exercicio */
.vernapratica{display:grid;gap:var(--s2)}
.vernapratica__cab{display:flex;flex-wrap:wrap;gap:var(--s2);align-items:center}
.vernapratica__cab .dica{font-size:.82rem;color:var(--muted);flex:1 1 220px}
.vernapratica iframe{width:100%;height:min(78vh,760px);border:1px solid var(--line);border-radius:var(--r);background:var(--bg)}

/* modo incorporado (iframe dentro do exercicio): sem menu, perfil nem moldura */
body.lab-embed{overflow:auto}
.lab-embed #menu,.lab-embed #perfil,.lab-embed .lab__topo{display:none}
.lab-embed .app{display:block;height:auto;padding:var(--s2)}
.lab-embed .conteudo{overflow:visible;margin:0;padding:0}
.lab-embed .lab{padding:var(--s3);gap:var(--s4);box-shadow:none}

@media(max-width:720px){
  .lab{padding:var(--s4);gap:var(--s4)}
  .lab__controles{gap:var(--s3)}
  .lab__transporte{flex:1 1 100%}.lab__transporte .btn{flex:1}
  .lab__vel{flex:1 1 40%}.lab__desafio{flex:1 1 100%;justify-content:center}
  .lab__palco{padding:var(--s3);min-height:220px}
  .barras{height:210px}.barra{padding:0 2px}.barra__col b{font-size:.7rem}
  .cel__marca{font-size:.55rem}
  .lab__opcoes{grid-template-columns:minmax(0,1fr)}
}
```

### `frontend/js/lab-sims.js` (263 lines, NEW)

```javascript
// Grimorio Vivo — logica dos simuladores (sem DOM; testavel em Node).
// Cada simulador gera uma lista de PASSOS. Um passo e um retrato do estado + uma narracao em portugues.
// Se o passo tem `pergunta`, o modo Desafio pergunta ao usuario ANTES de revelar o passo (prever o resultado).
(function (raiz) {
  "use strict";

  // ---------- utilitarios ----------
  const clonar = (t) => (t ? { v: t.v, l: clonar(t.l), r: clonar(t.r) } : null);
  const alt = (t) => (t ? 1 + Math.max(alt(t.l), alt(t.r)) : 0);
  const fb = (t) => (t ? alt(t.l) - alt(t.r) : 0);
  const rotD = (y) => { const x = y.l; y.l = x.r; x.r = y; return x; };
  const rotE = (x) => { const y = x.r; x.r = y.l; y.l = x; return y; };
  const sorteio = (qtd, min, max) => {
    const s = new Set();
    while (s.size < qtd) s.add(min + Math.floor(Math.random() * (max - min + 1)));
    return [...s];
  };

  // Le uma lista de inteiros ("5, 2; 9 1"). Devolve {valores} ou {erro}.
  function numeros(txt, { min = 1, max = 99, qtd = 12, minQtd = 2, unicos = false } = {}) {
    const partes = String(txt || "").split(/[\s,;]+/).filter(Boolean);
    if (partes.length < minQtd) return { erro: "Informe pelo menos " + minQtd + " valores separados por vírgula." };
    if (partes.length > qtd) return { erro: "Use no máximo " + qtd + " valores para a visualização ficar legível." };
    const v = partes.map(Number);
    if (v.some((n) => !Number.isInteger(n) || n < min || n > max)) return { erro: "Use apenas números inteiros entre " + min + " e " + max + "." };
    if (unicos && new Set(v).size !== v.length) return { erro: "Não repita valores nesta simulação." };
    return { valores: v };
  }

  // ---------- 1) Bubble Sort ----------
  function gerarBubble({ valores }) {
    const n = valores.length, passos = [];
    let a = valores.map((v, i) => ({ id: i, v }));
    const snap = () => a.map((x) => ({ ...x }));
    passos.push({ a: snap(), ord: n, cmp: null, txt: "Vetor inicial. O Bubble Sort compara pares vizinhos e troca os que estão fora de ordem; a cada passada, o maior valor restante \"sobe\" até o fim." });
    let trocouAlgum = true;
    for (let p = 0; p < n - 1 && trocouAlgum; p++) {
      trocouAlgum = false;
      for (let j = 0; j < n - 1 - p; j++) {
        const x = a[j], y = a[j + 1], troca = x.v > y.v;
        passos.push({ a: snap(), ord: n - p, cmp: [j, j + 1], txt: "Passada " + (p + 1) + ": compare " + x.v + " (posição " + j + ") com " + y.v + " (posição " + (j + 1) + ")." });
        const pergunta = {
          enunciado: "Comparando " + x.v + " e " + y.v + ": o que o Bubble Sort faz?",
          opcoes: ["Troca os dois de lugar", "Mantém como está"], certa: troca ? 0 : 1,
          explica: troca ? x.v + " é maior que " + y.v + ", então ficariam fora de ordem: troca." : x.v + " não é maior que " + y.v + ": já estão em ordem, nada a fazer.",
        };
        if (troca) { a[j] = y; a[j + 1] = x; trocouAlgum = true; }
        passos.push({ a: snap(), ord: n - p, cmp: [j, j + 1], troca, pergunta,
          txt: troca ? "Troca feita: " + x.v + " avançou uma casa para a direita." : "Sem troca: " + x.v + " ≤ " + y.v + "." });
      }
      if (trocouAlgum && p < n - 2) {
        passos.push({ a: snap(), ord: n - 1 - p, cmp: null, txt: "Fim da passada " + (p + 1) + ": " + a[n - 1 - p].v + " chegou à posição final e não será mais comparado." });
      } else if (!trocouAlgum) {
        passos.push({ a: snap(), ord: 0, cmp: null, txt: "A passada " + (p + 1) + " não fez nenhuma troca: o vetor já está ordenado e o algoritmo pode parar (otimização que torna o melhor caso O(n))." });
      }
    }
    passos.push({ a: snap(), ord: 0, cmp: null, fim: true, txt: "Vetor ordenado: " + a.map((x) => x.v).join(", ") + ". No pior caso o Bubble Sort faz cerca de n²/2 comparações: O(n²)." });
    return passos;
  }

  // ---------- 2) Busca binaria ----------
  function gerarBusca({ valores, alvo }) {
    const a = [...valores].sort((x, y) => x - y), passos = [], n = a.length;
    let lo = 0, hi = n - 1, comps = 0;
    passos.push({ a, lo, hi, mid: null, txt: "Lista ordenada com " + n + " elementos. Procuramos o valor " + alvo + ". A busca binária só funciona porque a lista está ordenada." });
    while (lo <= hi) {
      const mid = Math.floor((lo + hi) / 2); comps++;
      passos.push({ a, lo, hi, mid, txt: "Intervalo [" + lo + ".." + hi + "]: o meio é o índice ⌊(" + lo + "+" + hi + ")/2⌋ = " + mid + ", valor " + a[mid] + ". Compare com o alvo " + alvo + "." });
      const cmp = alvo === a[mid] ? 0 : alvo < a[mid] ? 1 : 2;
      const pergunta = {
        enunciado: "O meio vale " + a[mid] + " e o alvo é " + alvo + ". O que fazer?",
        opcoes: ["Encontrou: encerrar", "Descartar a metade direita (seguir pela esquerda)", "Descartar a metade esquerda (seguir pela direita)"], certa: cmp,
        explica: cmp === 0 ? "Os valores são iguais: achamos o alvo." : cmp === 1 ? alvo + " < " + a[mid] + ": se existir, está à esquerda do meio." : alvo + " > " + a[mid] + ": se existir, está à direita do meio.",
      };
      if (cmp === 0) {
        passos.push({ a, lo, hi, mid, achou: mid, pergunta, txt: "Encontrado no índice " + mid + " após " + comps + " comparação(ões). Uma busca sequencial poderia precisar de até " + n + "." });
        return passos;
      }
      if (cmp === 1) hi = mid - 1; else lo = mid + 1;
      passos.push({ a, lo, hi, mid, pergunta, descartou: cmp === 1 ? "dir" : "esq",
        txt: cmp === 1 ? alvo + " é menor que " + a[mid] + ": descartamos o meio e tudo à direita. Novo intervalo: " + (lo <= hi ? "[" + lo + ".." + hi + "]" : "vazio") + "."
          : alvo + " é maior que " + a[mid] + ": descartamos o meio e tudo à esquerda. Novo intervalo: " + (lo <= hi ? "[" + lo + ".." + hi + "]" : "vazio") + "." });
    }
    passos.push({ a, lo, hi, mid: null, fim: true, txt: "O intervalo ficou vazio: " + alvo + " não está na lista (" + comps + " comparações). O custo cresce como log₂ n: O(log n)." });
    return passos;
  }

  // ---------- 3) Tabela hash (encadeamento) ----------
  function gerarHash({ valores, m }) {
    const tab = Array.from({ length: m }, () => []), passos = [];
    const snap = () => tab.map((c) => [...c]);
    passos.push({ tab: snap(), m, pos: null, txt: "Tabela vazia com " + m + " posições. Usaremos a função h(k) = k mod " + m + " e encadeamento: chaves que caem na mesma posição formam uma lista." });
    let colisoes = 0;
    for (const k of valores) {
      const r = k % m, ocupada = tab[r].length > 0;
      passos.push({ tab: snap(), m, pos: null, chave: k, txt: "Próxima chave a inserir: " + k + ". Calcule h(" + k + ") = " + k + " mod " + m + "." });
      const opc = [...new Set([r, (r + 1) % m, (r + 2) % m, (r + m - 1) % m])].sort((x, y) => x - y);
      const antes = [...tab[r]];
      tab[r].push(k);
      if (ocupada) colisoes++;
      passos.push({ tab: snap(), m, pos: r, chave: k, colisao: ocupada,
        pergunta: { enunciado: "Em qual posição cai a chave " + k + " com h(k) = k mod " + m + "?", opcoes: opc.map((x) => "Posição " + x), certa: opc.indexOf(r),
          explica: k + " mod " + m + " = " + r + " (o resto da divisão de " + k + " por " + m + ")." },
        txt: k + " mod " + m + " = " + r + ". " + (ocupada ? "Colisão! A posição " + r + " já guarda " + antes.join(" → ") + ": " + k + " entra no fim dessa lista." : "A posição " + r + " está livre: " + k + " é guardado ali.") });
    }
    const maior = Math.max(...tab.map((c) => c.length));
    passos.push({ tab: snap(), m, pos: null, fim: true, txt: "Inserção concluída: " + valores.length + " chaves em " + m + " posições (fator de carga " + (valores.length / m).toFixed(2) + "), " + colisoes + " colisão(ões), maior lista com " + maior + " chave(s). Se todas colidissem, a busca viraria O(n); com boa distribuição, é O(1) em média." });
    return passos;
  }

  // ---------- 4) BST ----------
  function gerarBST({ valores }) {
    let raiz = null; const passos = [];
    const snap = (extra) => ({ arvore: clonar(raiz), ...extra });
    passos.push(snap({ txt: "Árvore vazia. Regra da árvore binária de busca: à esquerda de um nó ficam valores menores; à direita, maiores." }));
    for (const v of valores) {
      if (!raiz) { raiz = { v, l: null, r: null }; passos.push(snap({ novo: v, txt: v + " é o primeiro valor: vira a raiz." })); continue; }
      let no = raiz; const caminho = [];
      for (;;) {
        caminho.push(no.v);
        passos.push(snap({ atual: no.v, caminho: [...caminho], txt: "Inserindo " + v + ": compare com o nó " + no.v + "." }));
        const esq = v < no.v;
        passos.push(snap({ atual: no.v, caminho: [...caminho],
          pergunta: { enunciado: "Inserindo " + v + ", nó atual " + no.v + ". Para onde seguir?", opcoes: ["Esquerda", "Direita"], certa: esq ? 0 : 1,
            explica: v + (esq ? " < " : " > ") + no.v + ": " + (esq ? "valores menores ficam à esquerda." : "valores maiores ficam à direita.") },
          txt: v + (esq ? " é menor" : " é maior") + " que " + no.v + ": seguir para a " + (esq ? "esquerda." : "direita.") }));
        const prox = esq ? no.l : no.r;
        if (!prox) {
          const novo = { v, l: null, r: null };
          if (esq) no.l = novo; else no.r = novo;
          passos.push(snap({ novo: v, caminho: [...caminho], txt: "Posição vazia encontrada: " + v + " vira filho " + (esq ? "esquerdo" : "direito") + " de " + no.v + "." }));
          break;
        }
        no = prox;
      }
    }
    const emOrdem = [...valores].sort((x, y) => x - y);
    passos.push(snap({ fim: true, txt: "Árvore pronta (altura " + alt(raiz) + "). O percurso em ordem lê as chaves ordenadas: " + emOrdem.join(", ") + ". Cada busca desce um caminho: O(altura)." }));
    return passos;
  }

  // ---------- 5) AVL ----------
  const ROT = ["Rotação simples à direita", "Rotação simples à esquerda", "Rotação dupla esquerda-direita", "Rotação dupla direita-esquerda"];
  const CASO = { LL: 0, RR: 1, LR: 2, RL: 3 };
  const EXPLICA = {
    LL: "Fator +2 e o filho esquerdo pende para a esquerda (caso esquerda-esquerda): uma rotação simples à direita resolve.",
    RR: "Fator −2 e o filho direito pende para a direita (caso direita-direita): uma rotação simples à esquerda resolve.",
    LR: "Fator +2, mas o filho esquerdo pende para a direita (caso esquerda-direita): primeiro gira-se o filho à esquerda, depois o nó à direita.",
    RL: "Fator −2, mas o filho direito pende para a esquerda (caso direita-esquerda): primeiro gira-se o filho à direita, depois o nó à esquerda.",
  };

  function gerarAVL({ valores }) {
    let raiz = null; const passos = [];
    const snap = (extra) => ({ arvore: clonar(raiz), fb: true, ...extra });
    passos.push(snap({ txt: "Árvore AVL vazia. Regra extra: em todo nó, a diferença entre as alturas das subárvores (fator de balanceamento) deve ficar entre −1 e +1. Se passar disso, giramos." }));
    for (const v of valores) {
      if (!raiz) { raiz = { v, l: null, r: null }; passos.push(snap({ novo: v, txt: v + " é a primeira chave: vira a raiz (fator 0)." })); continue; }
      let no = raiz; const path = [];
      for (;;) {
        path.push(no);
        const cam = path.map((n) => n.v);
        passos.push(snap({ atual: no.v, caminho: cam, txt: "Inserindo " + v + ": compare com o nó " + no.v + "." }));
        const esq = v < no.v;
        passos.push(snap({ atual: no.v, caminho: cam,
          pergunta: { enunciado: "Inserindo " + v + ", nó atual " + no.v + ". Para onde seguir?", opcoes: ["Esquerda", "Direita"], certa: esq ? 0 : 1,
            explica: v + (esq ? " < " : " > ") + no.v + ": " + (esq ? "menores à esquerda." : "maiores à direita.") },
          txt: v + (esq ? " é menor" : " é maior") + " que " + no.v + ": seguir para a " + (esq ? "esquerda." : "direita.") }));
        const prox = esq ? no.l : no.r;
        if (!prox) {
          const novo = { v, l: null, r: null };
          if (esq) no.l = novo; else no.r = novo;
          passos.push(snap({ novo: v, caminho: cam, txt: v + " entra como filho " + (esq ? "esquerdo" : "direito") + " de " + no.v + ". Agora voltamos pelo caminho recalculando os fatores de balanceamento." }));
          break;
        }
        no = prox;
      }
      let girou = false;
      for (let k = path.length - 1; k >= 0 && !girou; k--) {
        const n = path[k], f = fb(n), he = alt(n.l), hd = alt(n.r);
        if (Math.abs(f) <= 1) {
          passos.push(snap({ atual: n.v, txt: "Subindo: nó " + n.v + " tem altura esquerda " + he + " e direita " + hd + " → fator " + (f > 0 ? "+" : "") + f + ". Equilibrado." }));
          continue;
        }
        passos.push(snap({ ruim: n.v, txt: "Subindo: nó " + n.v + " tem altura esquerda " + he + " e direita " + hd + " → fator " + (f > 0 ? "+" : "") + f + ". Desbalanceado! Precisa de rotação." }));
        const filho = f > 1 ? n.l : n.r;
        const caso = f > 1 ? (fb(filho) >= 0 ? "LL" : "LR") : (fb(filho) <= 0 ? "RR" : "RL");
        const pai = k > 0 ? path[k - 1] : null;
        const prender = (sub) => { if (!pai) raiz = sub; else if (pai.l === n) pai.l = sub; else pai.r = sub; };
        const pergunta = { enunciado: "O nó " + n.v + " ficou com fator " + (f > 0 ? "+" : "") + f + " e seu filho " + filho.v + " tem fator " + (fb(filho) > 0 ? "+" : "") + fb(filho) + ". Qual rotação corrige?",
          opcoes: ROT, certa: CASO[caso], explica: EXPLICA[caso] };
        const nv = n.v, fv = filho.v;
        if (caso === "LL") {
          const sub = rotD(n); prender(sub);
          passos.push(snap({ girou: sub.v, pergunta, txt: ROT[0] + " em " + nv + ": o filho " + fv + " sobe para o lugar de " + nv + ", e " + nv + " desce para a direita." }));
        } else if (caso === "RR") {
          const sub = rotE(n); prender(sub);
          passos.push(snap({ girou: sub.v, pergunta, txt: ROT[1] + " em " + nv + ": o filho " + fv + " sobe para o lugar de " + nv + ", e " + nv + " desce para a esquerda." }));
        } else if (caso === "LR") {
          n.l = rotE(n.l);
          passos.push(snap({ ruim: nv, girou: n.l.v, pergunta, txt: "1ª etapa da " + ROT[2].toLowerCase() + ": rotação à esquerda em " + fv + ". O neto " + n.l.v + " sobe e o caso vira esquerda-esquerda." }));
          const sub = rotD(n); prender(sub);
          passos.push(snap({ girou: sub.v, txt: "2ª etapa: rotação à direita em " + nv + ". " + sub.v + " vira a raiz desta subárvore." }));
        } else {
          n.r = rotD(n.r);
          passos.push(snap({ ruim: nv, girou: n.r.v, pergunta, txt: "1ª etapa da " + ROT[3].toLowerCase() + ": rotação à direita em " + fv + ". O neto " + n.r.v + " sobe e o caso vira direita-direita." }));
          const sub = rotE(n); prender(sub);
          passos.push(snap({ girou: sub.v, txt: "2ª etapa: rotação à esquerda em " + nv + ". " + sub.v + " vira a raiz desta subárvore." }));
        }
        girou = true;
        passos.push(snap({ txt: "Árvore rebalanceada: uma rotação (simples ou dupla) basta por inserção, e a altura da subárvore volta ao que era antes de inserir " + v + "." }));
      }
    }
    passos.push(snap({ fim: true, txt: "AVL concluída com altura " + alt(raiz) + " para " + valores.length + " chaves. A altura nunca passa de ~1,44·log₂(n), então busca, inserção e remoção são O(log n) — sem degenerar em lista como a BST." }));
    return passos;
  }

  // ---------- catalogo ----------
  const SIMS = {
    bubble: { titulo: "Bubble Sort", icone: "arrow-down-up", tom: "#d0343e",
      resumo: "Veja os vizinhos serem comparados e trocados até o caos virar ordem.",
      fato: "Pior caso O(n²) · melhor caso O(n) com parada antecipada · estável.",
      campos: [{ id: "v", rot: "Valores (2 a 10, inteiros de 1 a 99)", padrao: "5, 2, 9, 1, 6, 3" }],
      aleatorio: () => ({ v: sorteio(7, 1, 99).join(", ") }),
      ler: (f) => { const r = numeros(f.v, { qtd: 10 }); return r.erro ? r : { entrada: { valores: r.valores } }; },
      gerar: gerarBubble, manual: true },
    busca: { titulo: "Busca Binária", icone: "search", tom: "#b89a5e",
      resumo: "A cada passo metade do reino é descartada. Acompanhe o intervalo encolher.",
      fato: "Exige lista ordenada · O(log n): 1 milhão de itens em ~20 comparações.",
      campos: [{ id: "v", rot: "Valores (2 a 16; serão ordenados)", padrao: "3, 8, 12, 17, 21, 26, 33, 40, 47, 55, 62, 71" }, { id: "alvo", rot: "Valor procurado", padrao: "47", curto: true }],
      aleatorio: () => { const v = sorteio(12, 1, 99).sort((a, b) => a - b); return { v: v.join(", "), alvo: String(v[Math.floor(Math.random() * v.length)]) }; },
      ler: (f) => { const r = numeros(f.v, { qtd: 16, unicos: true }); if (r.erro) return r; const alvo = Number(f.alvo);
        if (!Number.isInteger(alvo) || alvo < 1 || alvo > 99) return { erro: "O valor procurado deve ser um inteiro entre 1 e 99." };
        return { entrada: { valores: r.valores, alvo } }; },
      gerar: gerarBusca },
    hash: { titulo: "Tabela Hash", icone: "hash", tom: "#6f8fb5",
      resumo: "Chaves viram posições por uma função de espalhamento; colisões formam listas.",
      fato: "Média O(1) com boa função e fator de carga baixo · pior caso O(n).",
      campos: [{ id: "v", rot: "Chaves (2 a 12, inteiros de 1 a 99)", padrao: "15, 22, 9, 36, 12, 25, 41" }, { id: "m", rot: "Posições (3 a 13)", padrao: "7", curto: true }],
      aleatorio: () => ({ v: sorteio(8, 1, 99).join(", "), m: String(5 + Math.floor(Math.random() * 4)) }),
      ler: (f) => { const r = numeros(f.v, { qtd: 12, unicos: true }); if (r.erro) return r; const m = Number(f.m);
        if (!Number.isInteger(m) || m < 3 || m > 13) return { erro: "O número de posições deve ser um inteiro entre 3 e 13." };
        return { entrada: { valores: r.valores, m } }; },
      gerar: gerarHash },
    bst: { titulo: "Árvore Binária de Busca", icone: "network", tom: "#3f9a5a",
      resumo: "Insira valores e acompanhe o caminho da raiz até o lugar de cada um.",
      fato: "Busca e inserção em O(altura): O(log n) se equilibrada, O(n) se degenerar.",
      campos: [{ id: "v", rot: "Valores (2 a 12, sem repetir)", padrao: "50, 30, 70, 20, 40, 60, 80" }],
      aleatorio: () => ({ v: sorteio(8, 1, 99).join(", ") }),
      ler: (f) => { const r = numeros(f.v, { qtd: 12, unicos: true }); return r.erro ? r : { entrada: { valores: r.valores } }; },
      gerar: gerarBST },
    avl: { titulo: "Árvore AVL", icone: "network", tom: "#8fbf6a",
      resumo: "A árvore que se endireita sozinha: veja fatores de balanceamento e rotações.",
      fato: "Altura ≤ ~1,44·log₂ n · busca, inserção e remoção em O(log n).",
      campos: [{ id: "v", rot: "Valores (2 a 12, sem repetir)", padrao: "10, 20, 30, 40, 50, 25" }],
      aleatorio: () => ({ v: sorteio(8, 1, 99).join(", ") }),
      ler: (f) => { const r = numeros(f.v, { qtd: 12, unicos: true }); return r.erro ? r : { entrada: { valores: r.valores } }; },
      gerar: gerarAVL },
  };

  const API = { SIMS, ROT, utils: { clonar, alt, fb, numeros } };
  raiz.AQSims = API;
  if (typeof module !== "undefined" && module.exports) module.exports = API;
})(typeof window !== "undefined" ? window : globalThis);
```

### `frontend/js/lab.js` (284 lines, NEW)

```javascript
// Grimorio Vivo — interface: player passo a passo, desenhistas por simulador, Modo Desafio e maestria.
// Depende de: ui.js (esc, ic, Sessao, SEM_MOVIMENTO) e lab-sims.js (AQSims).
(function () {
  "use strict";
  const { SIMS } = window.AQSims;
  const q = (id) => document.getElementById(id);
  const consulta = new URLSearchParams(location.search);
  if (consulta.get("embed") === "1") document.body.classList.add("lab-embed");

  // ---------- maestria (guardada apenas neste navegador) ----------
  const NOMES = ["Sem treino", "Noviço", "Adepto", "Mestre"];
  const chaveM = () => "aq_maestria_" + ((Sessao.obter() || {}).nomeUsuario || "visitante");
  const lerM = () => { try { return JSON.parse(localStorage.getItem(chaveM())) || {}; } catch (e) { return {}; } };
  const gravarM = (m) => { try { localStorage.setItem(chaveM(), JSON.stringify(m)); } catch (e) { /* sem armazenamento local */ } };
  const nivelM = (s) => (!s || !s.t ? 0 : s.t >= 10 && s.a / s.t >= 0.8 ? 3 : s.t >= 5 && s.a / s.t >= 0.6 ? 2 : 1);

  // ---------- estado ----------
  let simId = SIMS[consulta.get("sim")] ? consulta.get("sim") : "bubble";
  let passos = [], i = 0, tocando = false, temporizador = null, desafio = false;
  let pendente = null, respondidos = new Map(), sessao = { a: 0, t: 0, seq: 0 };
  let manual = null;

  // ---------- desenhistas ----------
  const R = {};

  // Bubble: barras com id estavel, para a troca ser animada (transicao de `left`).
  R.bubble = {
    montar(palco, e) {
      const max = Math.max(...e.valores);
      palco.innerHTML = `<div class="barras" style="--n:${e.valores.length}">${e.valores.map((v, id) =>
        `<div class="barra" data-id="${id}" style="--i:${id}"><span class="barra__col" style="height:${Math.max(8, (v / max) * 100)}%"><b>${v}</b></span></div>`).join("")}</div>`;
    },
    desenhar(palco, p) {
      p.a.forEach((x, pos) => {
        const el = palco.querySelector(`.barra[data-id="${x.id}"]`);
        if (!el) return;
        el.style.setProperty("--i", pos);
        el.className = "barra" + (p.cmp && p.cmp.includes(pos) ? (p.troca ? " barra--troca" : " barra--cmp") : "") + (pos >= p.ord ? " barra--ok" : "");
      });
    },
  };

  R.busca = {
    montar() {},
    desenhar(palco, p) {
      const n = p.a.length;
      palco.innerHTML = `<div class="celulas" style="--n:${n}">${p.a.map((v, k) => {
        const fora = k < p.lo || k > p.hi, cls = (fora ? " cel--fora" : "") + (k === p.mid ? " cel--meio" : "") + (p.achou === k ? " cel--achou" : "");
        const marca = [k === p.lo && p.lo <= p.hi ? "início" : "", k === p.hi && p.lo <= p.hi ? "fim" : "", k === p.mid ? "meio" : ""].filter(Boolean).join(" · ");
        return `<div class="cel${cls}"><span class="cel__marca">${marca}</span><span class="cel__v">${v}</span><span class="cel__i">${k}</span></div>`;
      }).join("")}</div>`;
    },
  };

  R.hash = {
    montar() {},
    desenhar(palco, p) {
      palco.innerHTML = `<div class="hashtab">${p.tab.map((cadeia, k) => `<div class="hl${p.pos === k ? " hl--alvo" : ""}${p.pos === k && p.colisao ? " hl--colisao" : ""}">
        <span class="hl__i">${k}</span>
        <span class="hl__cadeia">${cadeia.length ? cadeia.map((c, j) => `${j ? '<i class="seta" aria-hidden="true">→</i>' : ""}<span class="chave${p.pos === k && c === p.chave ? " chave--nova" : ""}">${c}</span>`).join("") : '<span class="vazio">vazio</span>'}</span></div>`).join("")}</div>
        ${p.chave != null && p.pos == null ? `<p class="hashtab__chave">Chave em jogo: <b>${p.chave}</b></p>` : ""}`;
    },
  };

  // Arvores (BST e AVL): posicoes por percurso em ordem; movimentos entre passos sao interpolados (rotacoes ficam visiveis).
  const arvore = {
    layout(t) {
      const pos = {}; let x = 0, prof = 0;
      (function f(n, d) { if (!n) return; f(n.l, d + 1); pos[n.v] = { x: 40 + x++ * 46, y: 34 + d * 66 }; prof = Math.max(prof, d); f(n.r, d + 1); })(t, 0);
      return { pos, w: Math.max(320, 80 + Math.max(0, x - 1) * 46), h: 70 + prof * 66 };
    },
    quadro(palco, t, pos, p, mostraFb) {
      const cam = new Set(p.caminho || []), fb = window.AQSims.utils.fb;
      let arestas = "", nos = "";
      (function percorrer(n) {
        if (!n) return;
        [n.l, n.r].forEach((c) => { if (c && pos[n.v] && pos[c.v]) arestas += `<line class="ar${cam.has(n.v) && cam.has(c.v) ? " ar--cam" : ""}" x1="${pos[n.v].x}" y1="${pos[n.v].y}" x2="${pos[c.v].x}" y2="${pos[c.v].y}"/>`; });
        const o = pos[n.v];
        if (o) {
          const cls = (p.atual === n.v ? " no--atual" : "") + (cam.has(n.v) ? " no--cam" : "") + (p.novo === n.v ? " no--novo" : "") + (p.ruim === n.v ? " no--ruim" : "") + (p.girou === n.v ? " no--girou" : "");
          const fator = fb(n), fbTxt = mostraFb ? `<text class="fb${Math.abs(fator) > 1 ? " fb--mau" : ""}" x="${o.x + 17}" y="${o.y - 14}">${fator > 0 ? "+" : ""}${fator}</text>` : "";
          nos += `<g class="noarv${cls}"><circle cx="${o.x}" cy="${o.y}" r="17"/><text x="${o.x}" y="${o.y + 5}" text-anchor="middle">${n.v}</text>${fbTxt}</g>`;
        }
        percorrer(n.l); percorrer(n.r);
      })(t);
      palco.querySelector("svg").innerHTML = arestas + nos;
    },
    desenhar(palco, p, mostraFb) {
      const t = p.arvore, { pos, w, h } = arvore.layout(t);
      if (!palco.querySelector("svg.arv")) palco.innerHTML = `<svg class="arv" role="img" aria-label="Árvore da simulação" preserveAspectRatio="xMidYMid meet"></svg>`;
      const svg = palco.querySelector("svg");
      svg.setAttribute("viewBox", `0 0 ${w} ${h}`);
      svg.style.maxHeight = Math.max(200, h * 1.1) + "px";
      cancelAnimationFrame(palco._raf);
      const de = palco._pos || {};
      const mover = Object.keys(pos).some((k) => de[k] && (de[k].x !== pos[k].x || de[k].y !== pos[k].y));
      const quadroEm = (k) => { const cur = {}; Object.keys(pos).forEach((v) => { const a = de[v] || pos[v], b = pos[v]; cur[v] = { x: a.x + (b.x - a.x) * k, y: a.y + (b.y - a.y) * k }; }); arvore.quadro(palco, t, cur, p, mostraFb); };
      if (!mover || SEM_MOVIMENTO) { quadroEm(1); }
      else {
        const t0 = performance.now(), dur = 520;
        const passo = (agora) => { const k = Math.min(1, (agora - t0) / dur), e = 1 - Math.pow(1 - k, 3); quadroEm(e); if (k < 1) palco._raf = requestAnimationFrame(passo); };
        palco._raf = requestAnimationFrame(passo);
      }
      palco._pos = pos;
    },
  };
  R.bst = { montar(palco) { palco._pos = null; }, desenhar: (palco, p) => arvore.desenhar(palco, p, false) };
  R.avl = { montar(palco) { palco._pos = null; }, desenhar: (palco, p) => arvore.desenhar(palco, p, true) };

  // ---------- abas, entrada ----------
  function montarAbas() {
    const m = lerM();
    q("abas").innerHTML = Object.entries(SIMS).map(([id, s]) => {
      const n = nivelM(m[id]);
      return `<button type="button" role="tab" id="aba-${id}" data-sim="${id}" aria-selected="${id === simId}" style="--tom:${s.tom}">
        <span class="hex">${ic(s.icone)}</span><span class="aba__txt"><b>${esc(s.titulo)}</b><span class="maes" title="${NOMES[n]}">${[1, 2, 3].map((k) => `<i class="${k <= n ? "on" : ""}"></i>`).join("")}</span></span></button>`;
    }).join("");
    q("abas").querySelectorAll("button").forEach((b) => b.addEventListener("click", () => trocarSim(b.dataset.sim)));
    const ativa = q("abas").querySelector("[aria-selected=true]"), faixa = q("abas"); // centraliza a aba ativa (mobile)
    if (ativa) faixa.scrollLeft = ativa.offsetLeft - (faixa.clientWidth - ativa.offsetWidth) / 2;
  }

  function montarCampos(valores) {
    const s = SIMS[simId];
    q("campos").innerHTML = s.campos.map((c) => `<label class="campo${c.curto ? " campo--curto" : ""}"><span>${esc(c.rot)}</span>
      <input name="${c.id}" type="text" inputmode="numeric" autocomplete="off" value="${esc((valores || {})[c.id] ?? c.padrao)}"></label>`).join("");
  }
  const lerCampos = () => Object.fromEntries([...q("campos").querySelectorAll("input")].map((x) => [x.name, x.value]));

  function trocarSim(id) {
    parar(); simId = id; manual = null;
    try { history.replaceState(null, "", "?" + new URLSearchParams({ ...(consulta.get("embed") ? { embed: "1" } : {}), sim: id })); } catch (e) { /* ignora */ }
    const s = SIMS[id];
    q("simTitulo").textContent = s.titulo; q("simResumo").textContent = s.resumo; q("simFato").textContent = s.fato;
    q("btnManual").hidden = !s.manual;
    document.querySelector(".lab").style.setProperty("--tom", s.tom);
    montarAbas(); montarCampos(); executar();
  }

  function executar(valores) {
    parar(); manual = null; document.querySelector(".lab").classList.remove("lab--manual");
    const s = SIMS[simId], r = s.ler(valores || lerCampos()), erro = q("erroEntrada");
    if (r.erro) { erro.textContent = r.erro; erro.hidden = false; return; }
    erro.hidden = true;
    passos = s.gerar(r.entrada); i = 0; pendente = null; respondidos = new Map(); sessao = { a: 0, t: 0, seq: 0 };
    q("palco").className = "lab__palco lab__palco--" + simId; q("palco")._pos = null;
    q("palco").innerHTML = ""; R[simId].montar(q("palco"), r.entrada);
    q("linha").max = passos.length - 1;
    mostrar(); atualizarPlacar();
  }

  // ---------- player ----------
  function mostrar() {
    const p = passos[i];
    R[simId].desenhar(q("palco"), p);
    q("narra").textContent = p.txt;
    q("linha").value = i;
    q("passoRotulo").textContent = "Passo " + (i + 1) + " de " + passos.length;
    q("btnInicio").disabled = q("btnAnt").disabled = i === 0 && !pendente;
    q("btnProx").disabled = i >= passos.length - 1 && !pendente;
    q("btnPlay").disabled = !!pendente;
    q("linha").disabled = desafio;
    q("controles").classList.toggle("tocando", tocando);
    q("btnPlay").setAttribute("aria-label", tocando ? "Pausar" : "Reproduzir");
  }

  function fecharPergunta() { pendente = null; q("pergunta").hidden = true; q("pergunta").innerHTML = ""; }

  function irPara(k) { fecharPergunta(); i = Math.max(0, Math.min(passos.length - 1, k)); mostrar(); }

  function avancar() {
    if (pendente) return false;
    if (i >= passos.length - 1) { parar(); return false; }
    const prox = passos[i + 1];
    if (desafio && prox.pergunta && !respondidos.has(i + 1)) { perguntar(i + 1); return false; }
    fecharPergunta(); i++; mostrar(); return true;
  }

  function perguntar(k) {
    pendente = k; parar();
    const pr = passos[k].pergunta, box = q("pergunta");
    box.hidden = false;
    box.innerHTML = `<p class="lab__pergunta-tit">${ic("swords")}<span>Preveja o próximo passo</span></p><p class="lab__pergunta-txt">${esc(pr.enunciado)}</p>
      <div class="lab__opcoes">${pr.opcoes.map((o, n) => `<button class="opcao" type="button" data-n="${n}"><span class="opcao__letra">${String.fromCharCode(65 + n)}</span><span class="opcao__texto">${esc(o)}</span></button>`).join("")}</div>`;
    box.querySelectorAll(".opcao").forEach((b) => b.addEventListener("click", () => responder(k, Number(b.dataset.n))));
    mostrar();
    box.querySelector(".opcao").focus({ preventScroll: true });
  }

  function responder(k, escolha) {
    const pr = passos[k].pergunta, certa = escolha === pr.certa;
    respondidos.set(k, certa);
    sessao.t++; if (certa) { sessao.a++; sessao.seq++; } else sessao.seq = 0;
    const m = lerM(), s = m[simId] || { a: 0, t: 0, seq: 0 };
    s.t++; if (certa) { s.a++; s.seq = (s.seq || 0) + 1; s.melhor = Math.max(s.melhor || 0, s.seq); } else s.seq = 0;
    m[simId] = s; gravarM(m);
    const box = q("pergunta");
    box.querySelectorAll(".opcao").forEach((b, n) => { b.disabled = true; if (n === pr.certa) b.classList.add("certa"); else if (n === escolha) b.classList.add("errada"); });
    box.insertAdjacentHTML("beforeend", `<p class="feedback ${certa ? "ok" : "erro"}">${ic(certa ? "circle-check" : "circle-x")}<span>${certa ? "Acertou! " : "Não foi dessa vez. "}${esc(pr.explica)}</span></p>`);
    pendente = null; i = k; mostrar(); atualizarPlacar(); montarAbas();
  }

  function atualizarPlacar() {
    const m = lerM(), s = m[simId] || { a: 0, t: 0 }, n = nivelM(s);
    q("placar").innerHTML = `<div class="placar__nivel"><span class="maes maes--grande">${[1, 2, 3].map((k) => `<i class="${k <= n ? "on" : ""}"></i>`).join("")}</span>
      <div><b>${NOMES[n]}</b> em ${esc(SIMS[simId].titulo)}<span class="muted">${s.t ? " · " + s.a + " acerto(s) em " + s.t + " previsões" + (s.melhor ? " · melhor sequência " + s.melhor : "") : " · ligue o Modo Desafio e preveja os passos para ganhar maestria"}</span></div></div>
      ${desafio && sessao.t ? `<div class="placar__sessao">Nesta execução: <b>${sessao.a}/${sessao.t}</b>${sessao.seq > 1 ? " · sequência " + sessao.seq : ""}</div>` : ""}
      <p class="muted placar__nota">A maestria fica salva só neste navegador (não é enviada ao servidor).</p>`;
  }

  function tocar() {
    if (tocando) return parar();
    if (i >= passos.length - 1) irPara(0);
    tocando = true; mostrar();
    const atraso = () => [2000, 1300, 800, 380][Number(q("velocidade").value) - 1];
    const tic = () => { if (!tocando) return; if (avancar()) temporizador = setTimeout(tic, atraso()); else parar(); };
    temporizador = setTimeout(tic, 250);
  }
  function parar() { tocando = false; clearTimeout(temporizador); if (passos.length) q("controles").classList.remove("tocando"); }

  // ---------- Bubble: ordenar a mao ----------
  function iniciarManual() {
    const r = SIMS.bubble.ler(lerCampos()); if (r.erro) { q("erroEntrada").textContent = r.erro; q("erroEntrada").hidden = false; return; }
    q("erroEntrada").hidden = true; parar(); fecharPergunta();
    const v = r.entrada.valores; let inv = 0;
    for (let a = 0; a < v.length; a++) for (let b = a + 1; b < v.length; b++) if (v[a] > v[b]) inv++;
    manual = { arr: v.map((x, id) => ({ id, v: x })), sel: null, trocas: 0, min: inv, fim: false };
    document.querySelector(".lab").classList.add("lab--manual");
    R.bubble.montar(q("palco"), { valores: v });
    q("palco").querySelectorAll(".barra").forEach((el) => { el.tabIndex = 0; el.setAttribute("role", "button"); el.addEventListener("click", () => cliqueManual(Number(el.dataset.id))); el.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); cliqueManual(Number(el.dataset.id)); } }); });
    pintarManual("Clique em uma barra e depois em uma vizinha para trocá-las. Ordene do menor para o maior com o mínimo de trocas.");
  }
  function cliqueManual(id) {
    if (!manual || manual.fim) return;
    const pos = manual.arr.findIndex((x) => x.id === id);
    if (manual.sel == null) { manual.sel = id; return pintarManual("Agora clique em uma barra vizinha para trocar de lugar (ou na mesma, para desmarcar)."); }
    if (manual.sel === id) { manual.sel = null; return pintarManual("Seleção desfeita."); }
    const ps = manual.arr.findIndex((x) => x.id === manual.sel);
    if (Math.abs(ps - pos) !== 1) { manual.sel = id; return pintarManual("Só vizinhos podem trocar de lugar — como no Bubble Sort. Barra selecionada: " + manual.arr[pos].v + "."); }
    [manual.arr[ps], manual.arr[pos]] = [manual.arr[pos], manual.arr[ps]]; manual.sel = null; manual.trocas++;
    const ordenado = manual.arr.every((x, k) => k === 0 || manual.arr[k - 1].v <= x.v);
    if (ordenado) {
      manual.fim = true;
      const dif = manual.trocas - manual.min;
      return pintarManual(dif === 0 ? "Perfeito! Ordenou com " + manual.trocas + " trocas — o mínimo possível (" + manual.min + ", o número de pares fora de ordem, as \"inversões\"). É exatamente o que o Bubble Sort faz."
        : "Ordenado com " + manual.trocas + " trocas. O mínimo era " + manual.min + " (o número de inversões: pares fora de ordem). Tente de novo com " + dif + " troca(s) a menos.");
    }
    pintarManual("Trocas: " + manual.trocas + " · mínimo possível: " + manual.min + ".");
  }
  function pintarManual(msg) {
    const ordenado = manual.fim;
    manual.arr.forEach((x, pos) => {
      const el = q("palco").querySelector(`.barra[data-id="${x.id}"]`); if (!el) return;
      el.style.setProperty("--i", pos);
      el.className = "barra" + (manual.sel === x.id ? " barra--cmp" : "") + (ordenado ? " barra--ok" : "");
    });
    q("narra").textContent = msg;
  }
  function sairManual() { if (!manual) return; manual = null; document.querySelector(".lab").classList.remove("lab--manual"); executar(); }

  // ---------- eventos ----------
  q("entrada").addEventListener("submit", (e) => { e.preventDefault(); executar(); });
  q("btnAleatorio").addEventListener("click", () => { montarCampos(SIMS[simId].aleatorio()); executar(); });
  q("btnManual").addEventListener("click", () => (manual ? sairManual() : iniciarManual()));
  q("btnInicio").addEventListener("click", () => irPara(0));
  q("btnAnt").addEventListener("click", () => { parar(); irPara(i - 1); });
  q("btnProx").addEventListener("click", () => { parar(); avancar(); });
  q("btnPlay").addEventListener("click", tocar);
  q("linha").addEventListener("input", (e) => { parar(); irPara(Number(e.target.value)); });
  q("btnDesafio").addEventListener("click", () => {
    desafio = !desafio; parar(); fecharPergunta();
    q("btnDesafio").setAttribute("aria-pressed", String(desafio));
    sessao = { a: 0, t: 0, seq: 0 }; respondidos = new Map();
    if (desafio) irPara(0); else mostrar();
    atualizarPlacar();
  });
  document.addEventListener("keydown", (e) => {
    if (/INPUT|TEXTAREA/.test((e.target.tagName || "")) && e.target.type !== "range") return;
    if (manual || (e.target.closest && e.target.closest(".opcao"))) return;
    if (e.key === "ArrowRight") { parar(); avancar(); } else if (e.key === "ArrowLeft") { parar(); irPara(i - 1); }
  });

  trocarSim(simId);
})();
```

### `dev-tools/testes/lab-sims.test.js` (56 lines, NEW)

```javascript
// Testes da logica dos simuladores. Uso: node dev-tools/testes/lab-sims.test.js
const assert = require("assert");
const { SIMS, utils } = require("../../frontend/js/lab-sims.js");
let ok = 0; const t = (n, f) => { f(); ok++; console.log("ok -", n); };
const ler = (id, f) => { const r = SIMS[id].ler(f); assert(!r.erro, r.erro); return r.entrada; };
const emOrdem = (t) => (t ? [...emOrdem(t.l), t.v, ...emOrdem(t.r)] : []);
const bst = (t, lo = -1e9, hi = 1e9) => !t || (t.v > lo && t.v < hi && bst(t.l, lo, t.v) && bst(t.r, t.v, hi));
const avl = (t) => !t || (Math.abs(utils.fb(t)) <= 1 && avl(t.l) && avl(t.r));
const perguntasValidas = (ps) => ps.forEach((p) => { if (p.pergunta) { assert(p.pergunta.certa >= 0 && p.pergunta.certa < p.pergunta.opcoes.length); assert(p.pergunta.explica); } });

t("bubble ordena e marca fim", () => {
  for (let k = 0; k < 50; k++) {
    const e = ler("bubble", SIMS.bubble.aleatorio()); const ps = SIMS.bubble.gerar(e);
    const fim = ps[ps.length - 1]; assert(fim.fim);
    assert.deepStrictEqual(fim.a.map((x) => x.v), [...e.valores].sort((a, b) => a - b)); perguntasValidas(ps);
  }
  const ps = SIMS.bubble.gerar(ler("bubble", { v: "1, 2, 3, 4" })); // ja ordenado: sai na 1a passada
  assert(ps.filter((p) => p.pergunta).length === 3);
});
t("busca binaria acha e nao acha", () => {
  const a = SIMS.busca.gerar(ler("busca", { v: "3, 8, 12, 17, 21, 26, 33, 40, 47, 55, 62, 71", alvo: "47" }));
  assert(a.some((p) => p.achou === 8)); perguntasValidas(a);
  const b = SIMS.busca.gerar(ler("busca", { v: "2, 4, 6", alvo: "5" })); assert(b[b.length - 1].fim && /não está/.test(b[b.length - 1].txt));
  for (let k = 0; k < 50; k++) { const f = SIMS.busca.aleatorio(); const ps = SIMS.busca.gerar(ler("busca", f)); assert(ps.some((p) => p.achou != null)); }
});
t("hash posicao = k mod m e colisoes", () => {
  const e = ler("hash", { v: "15, 22, 8, 36", m: "7" }); const ps = SIMS.hash.gerar(e); perguntasValidas(ps);
  const ult = ps[ps.length - 1]; assert.deepStrictEqual(ult.tab[1], [15, 22, 8, 36]); // todos mod 7 = 1
  assert(ps.filter((p) => p.colisao).length === 3);
  const q = ps.find((p) => p.pergunta); assert.strictEqual(q.pergunta.opcoes[q.pergunta.certa], "Posição 1");
});
t("bst mantem invariante e em-ordem", () => {
  for (let k = 0; k < 50; k++) {
    const e = ler("bst", SIMS.bst.aleatorio()); const ps = SIMS.bst.gerar(e); perguntasValidas(ps);
    const fim = ps[ps.length - 1]; assert(bst(fim.arvore)); assert.deepStrictEqual(emOrdem(fim.arvore), [...e.valores].sort((a, b) => a - b));
  }
});
t("avl sempre balanceada, em cada retrato apos rotacao", () => {
  for (let k = 0; k < 200; k++) {
    const e = ler("avl", SIMS.avl.aleatorio()); const ps = SIMS.avl.gerar(e); perguntasValidas(ps);
    const fim = ps[ps.length - 1]; assert(bst(fim.arvore) && avl(fim.arvore)); assert.deepStrictEqual(emOrdem(fim.arvore), [...e.valores].sort((a, b) => a - b));
    ps.forEach((p, i) => { if (/rebalanceada/.test(p.txt)) assert(avl(p.arvore), "passo " + i); });
  }
  const ps = SIMS.avl.gerar(ler("avl", { v: "10, 20, 30, 40, 50, 25" }));
  const rots = ps.filter((p) => p.pergunta && p.pergunta.opcoes.length === 4).map((p) => p.pergunta.opcoes[p.pergunta.certa]);
  assert.deepStrictEqual(rots, ["Rotação simples à esquerda", "Rotação simples à esquerda", "Rotação dupla direita-esquerda"]);
  const mono = SIMS.avl.gerar(ler("avl", { v: "3, 2, 1" })).filter((p) => p.pergunta && p.pergunta.opcoes.length === 4);
  assert.strictEqual(mono[0].pergunta.opcoes[mono[0].pergunta.certa], "Rotação simples à direita");
  const lr = SIMS.avl.gerar(ler("avl", { v: "30, 10, 20" })).filter((p) => p.pergunta && p.pergunta.opcoes.length === 4);
  assert.strictEqual(lr[0].pergunta.opcoes[lr[0].pergunta.certa], "Rotação dupla esquerda-direita");
});
t("validacao de entrada em portugues", () => {
  assert(SIMS.bubble.ler({ v: "1" }).erro); assert(SIMS.bubble.ler({ v: "a, b" }).erro); assert(SIMS.avl.ler({ v: "1, 1" }).erro);
  assert(SIMS.hash.ler({ v: "1, 2", m: "2" }).erro); assert(SIMS.busca.ler({ v: "1, 2", alvo: "x" }).erro);
});
console.log("\n" + ok + " grupos de teste passaram");
```

### `dev-tools/testes/e2e_lab.py` (58 lines, NEW)

```python
"""E2E opcional do Grimorio Vivo (Playwright + Chromium). Requer o mock rodando: python3 dev-tools/mock-api/mock-api.py (da raiz do projeto).
Uso: pip install playwright && playwright install chromium && python3 dev-tools/testes/e2e_lab.py   (screenshots em /tmp/s_*.png)"""
import asyncio, json
from playwright.async_api import async_playwright
BASE="http://127.0.0.1:5500/"
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch()
        ctx = await b.new_context(viewport={"width":1440,"height":1000})
        await ctx.add_init_script("sessionStorage.setItem('aq_usuario', JSON.stringify({nomeUsuario:'mock',token:'t',pontuacao:120,xp:340,nivel:3}))")
        pg = await ctx.new_page(); erros=[]
        pg.on("pageerror", lambda e: erros.append("PAGEERR "+str(e)))
        pg.on("console", lambda m: erros.append("CONSOLE "+m.text) if m.type=="error" and "8080" not in m.text and "Failed to load resource" not in m.text else None)
        await pg.goto(BASE+"laboratorio.html"); await pg.wait_for_selector(".barra")
        await pg.screenshot(path="/tmp/s_bubble.png")
        # avancar ate o fim com o botao Proximo
        n = await pg.evaluate("document.getElementById('linha').max")
        for _ in range(int(n)): await pg.click("#btnProx")
        print("bubble fim:", await pg.inner_text("#narra"))
        # modo manual
        await pg.click("#btnManual"); 
        ids = await pg.evaluate("[...document.querySelectorAll('.barra')].map(b=>b.dataset.id)")
        await pg.click(".barra[data-id='0']"); await pg.click(".barra[data-id='1']")
        print("manual:", await pg.inner_text("#narra"))
        await pg.screenshot(path="/tmp/s_manual.png"); await pg.click("#btnManual")
        for sim in ["busca","hash","bst","avl"]:
            await pg.click(f"#aba-{sim}"); await pg.wait_for_timeout(300)
            n = int(await pg.evaluate("document.getElementById('linha').max"))
            await pg.fill("#linha", "0") if False else None
            for _ in range(n): await pg.click("#btnProx")
            await pg.wait_for_timeout(700)
            print(sim, "fim:", (await pg.inner_text("#narra"))[:110])
            await pg.screenshot(path=f"/tmp/s_{sim}.png")
        # modo desafio no AVL
        await pg.click("#aba-avl"); await pg.click("#btnDesafio")
        respostas=0; certas=0
        for _ in range(200):
            if await pg.is_visible("#pergunta .opcao"):
                # responde sempre errado na 1a, certo nas demais
                opts = await pg.query_selector_all("#pergunta .opcao")
                await opts[0].click(); respostas+=1
                if await pg.query_selector("#pergunta .opcao.certa >> nth=0") and await pg.evaluate("document.querySelector('#pergunta .opcao.certa').dataset.n")=='0': certas+=1
                if respostas==6: await pg.screenshot(path="/tmp/s_desafio.png")
            if await pg.is_disabled("#btnProx"): break
            await pg.click("#btnProx")
        print("desafio: respondeu",respostas,"placar:",(await pg.inner_text("#placar"))[:160].replace("\n"," | "))
        # entrada invalida
        await pg.fill("input[name=v]","1, 1"); await pg.click("button[type=submit]"); print("erro:", await pg.inner_text("#erroEntrada"))
        # pagina de exercicio com iframe
        await pg.goto(BASE+"exercicio.html?modulo=5"); await pg.wait_for_selector(".opcao")
        print("painel pratica visivel:", await pg.is_visible("#btnPratica"))
        await pg.click("#btnPratica"); await pg.wait_for_selector("#praticaCorpo iframe"); await pg.wait_for_timeout(900)
        await pg.screenshot(path="/tmp/s_exercicio.png")
        await pg.goto(BASE+"modulos.html"); await pg.wait_for_selector(".convite"); await pg.screenshot(path="/tmp/s_modulos.png")
        await pg.set_viewport_size({"width":390,"height":844}); await pg.goto(BASE+"laboratorio.html?sim=hash"); await pg.wait_for_selector(".hl"); await pg.screenshot(path="/tmp/s_mobile.png")
        print("ERROS:", erros if erros else "nenhum")
        await b.close()
asyncio.run(main())
```
