// Camada unica de comunicacao com o backend (Spring Boot).
// Endereco da API: usa o mesmo host da pagina na porta 8080 (assim localhost e 127.0.0.1 funcionam).
// Para outro endereco, defina window.AQ_API_URL antes de carregar este arquivo.
const API_URL = window.AQ_API_URL || "http://" + (location.hostname || "localhost") + ":8080/api";

function tokenAtual() {
  try { return (JSON.parse(sessionStorage.getItem("aq_usuario")) || {}).token || null; } catch (e) { return null; }
}

async function apiFetch(caminho, opcoes = {}) {
  const cabecalhos = { "Content-Type": "application/json" };
  const token = tokenAtual();
  if (token) cabecalhos["Authorization"] = "Bearer " + token; // a API protege tudo, exceto o login
  const resposta = await fetch(API_URL + caminho, { ...opcoes, headers: cabecalhos });
  if (resposta.status === 401 && caminho !== "/auth/login") {
    // Sessao ausente, expirada ou encerrada no servidor: volta ao login.
    sessionStorage.removeItem("aq_usuario");
    if (!/index\.html$|\/$/.test(location.pathname)) location.href = "index.html";
  }
  if (!resposta.ok) {
    const e = new Error("Erro " + resposta.status);
    e.status = resposta.status;
    try { e.mensagem = (await resposta.json()).erro; } catch (x) { /* sem corpo */ }
    throw e;
  }
  const texto = await resposta.text();
  return texto ? JSON.parse(texto) : null;
}

const Api = {
  login: (nomeUsuario, senha) =>
    apiFetch("/auth/login", { method: "POST", body: JSON.stringify({ nomeUsuario, senha }) }),
  registrar: (nomeUsuario, senha) =>
    apiFetch("/auth/registrar", { method: "POST", body: JSON.stringify({ nomeUsuario, senha }) }),
  escolherAvatar: (avatar) =>
    apiFetch("/auth/me/avatar", { method: "POST", body: JSON.stringify({ avatar }) }),
  enviarAvatar: (imagem) =>
    apiFetch("/auth/me/avatar/personalizado", { method: "POST", body: JSON.stringify({ imagem }) }),
  logout: () => apiFetch("/auth/logout", { method: "POST" }),
  eu: () => apiFetch("/auth/me"),
  listarModulos: () => apiFetch("/modulos"),
  abrirModulo: (id) => apiFetch("/modulos/" + id),
  responder: (idExercicio, resposta) =>
    apiFetch("/modulos/exercicios/" + idExercicio + "/resposta", {
      method: "POST",
      body: JSON.stringify({ resposta }),
    }),
};
