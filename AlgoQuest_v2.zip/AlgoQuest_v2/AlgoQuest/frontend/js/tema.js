// Tema por categoria do avatar (unica logica de tema do app). Carregar no <head>, depois de avatares-catalogo.js.
// A categoria vem do catalogo (cat do avatar): "herois" | "aldeoes" | "monstros". Imagem personalizada (ou sem
// avatar) = sem tema (aparencia original). O backend e a fonte da verdade: o avatar chega em login e /me.
const Tema = (() => {
  const raiz = document.documentElement;
  function categoria(u) {
    if (!u || !u.avatar || u.avatar === "personalizado") return null;
    const a = AVATAR_CATALOGO.find((x) => x.id === u.avatar);
    return a ? a.cat : null;
  }
  function aplicar(u) {
    const c = categoria(u);
    if (c) raiz.dataset.tema = c; else delete raiz.dataset.tema;
    return c;
  }
  try { aplicar(JSON.parse(sessionStorage.getItem("aq_usuario"))); } catch (e) { aplicar(null); } // evita "piscar" ao carregar
  return { categoria, aplicar };
})();
