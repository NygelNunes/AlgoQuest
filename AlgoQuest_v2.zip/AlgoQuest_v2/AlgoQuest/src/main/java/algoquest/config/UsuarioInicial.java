package algoquest.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.SmartInitializingSingleton;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import algoquest.model.Usuario;
import algoquest.repository.UsuarioRepositorio;
import algoquest.model.Avatar;
import algoquest.util.HashSenha;

/**
 * Cria, se ainda nao existir, o usuario definido por ALGOQUEST_USUARIO_INICIAL / ALGOQUEST_SENHA_INICIAL.
 * Existe porque a API nao tem cadastro publico. A senha vem do ambiente e e gravada apenas como hash.
 * Roda depois que todos os singletons (inclusive a migracao Flyway) estao prontos.
 */
@Component
public class UsuarioInicial implements SmartInitializingSingleton {

    private static final Logger LOG = LoggerFactory.getLogger(UsuarioInicial.class);

    private final UsuarioRepositorio usuarios;
    private final HashSenha hashSenha;
    private final String nome;
    private final String senha;

    public UsuarioInicial(UsuarioRepositorio usuarios, HashSenha hashSenha,
                          @Value("${algoquest.usuario-inicial.nome:}") String nome,
                          @Value("${algoquest.usuario-inicial.senha:}") String senha) {
        this.usuarios = usuarios;
        this.hashSenha = hashSenha;
        this.nome = nome == null ? "" : nome.trim();
        this.senha = senha == null ? "" : senha;
    }

    @Override
    public void afterSingletonsInstantiated() {
        if (nome.isEmpty() && senha.isEmpty()) {
            return;
        }
        if (nome.isEmpty() || senha.length() < 8 || nome.length() > 50 || senha.length() > 128) {
            LOG.warn("Usuario inicial ignorado: informe nome (ate 50 caracteres) e senha (8 a 128 caracteres).");
            return;
        }
        if (usuarios.buscarPorNome(nome) != null) {
            return;
        }
        Usuario novo = new Usuario(0, nome, hashSenha.gerar(senha));
        novo.setAvatar(Avatar.padraoPara(nome, java.util.concurrent.ThreadLocalRandom.current()));
        usuarios.salvar(novo);
        LOG.info("Usuario inicial '{}' criado.", nome);
    }
}
