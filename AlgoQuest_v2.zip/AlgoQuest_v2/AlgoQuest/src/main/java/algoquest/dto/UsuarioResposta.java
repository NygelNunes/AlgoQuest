package algoquest.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

import algoquest.model.Usuario;

/**
 * Representacao UNICA do usuario na API (login, /me e resultado de resposta).
 * Nunca contem senha nem hash. {@code token} so aparece no login.
 * Nomes iguais aos que o frontend ja le: nomeUsuario, pontuacao, xp, nivel, xpProximoNivel.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record UsuarioResposta(int id, String nomeUsuario, int pontuacao, int xp, int nivel,
                              int xpProximoNivel, String avatar, String avatarImagem, String token) {

    public static UsuarioResposta de(Usuario u) {
        return new UsuarioResposta(u.getId(), u.getNomeUsuario(), u.getPontuacao(), u.getXp(), u.getNivel(),
                u.getXpProximoNivel(), u.getAvatar(), u.getAvatarImagem(), null);
    }

    public static UsuarioResposta comToken(Usuario u, String token) {
        return new UsuarioResposta(u.getId(), u.getNomeUsuario(), u.getPontuacao(), u.getXp(), u.getNivel(),
                u.getXpProximoNivel(), u.getAvatar(), u.getAvatarImagem(), token);
    }
}
