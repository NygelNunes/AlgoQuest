package algoquest.dto;

/** {@code avatar}: id do catalogo. {@code imagem}: data URL (so no envio de imagem personalizada). */
public record AvatarRequisicao(String avatar, String imagem) {
}
