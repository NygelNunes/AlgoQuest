package algoquest.service;

import java.util.concurrent.ThreadLocalRandom;

import org.springframework.stereotype.Service;

import algoquest.exception.ErroApi;
import algoquest.model.Avatar;
import algoquest.model.Usuario;
import algoquest.repository.UsuarioRepositorio;

/** Avatar do usuario AUTENTICADO. Nenhum metodo recebe id de usuario: sempre age sobre o dono do token. */
@Service
public class ServicoAvatar {

    private final UsuarioRepositorio usuarios;

    public ServicoAvatar(UsuarioRepositorio usuarios) {
        this.usuarios = usuarios;
    }

    /** Sorteia o padrao para o nome informado (so para contas novas ou ainda sem avatar). */
    public String sortearPadrao(String nomeUsuario) {
        return Avatar.padraoPara(nomeUsuario, ThreadLocalRandom.current());
    }

    /** Conta antiga sem avatar: atribui um padrao uma unica vez; quem ja tem avatar nunca e alterado. */
    public void garantirAvatar(Usuario u) {
        if (u.getAvatar() == null) {
            String padrao = sortearPadrao(u.getNomeUsuario());
            if (usuarios.definirAvatarSeVazio(u.getId(), padrao)) {
                u.setAvatar(padrao);
            } else { // outra requisicao atribuiu primeiro: usa o valor gravado
                Usuario atual = usuarios.buscarPorId(u.getId());
                u.setAvatar(atual == null ? null : atual.getAvatar());
            }
        }
    }

    public Usuario escolher(Usuario u, String id) {
        if (!Avatar.idDoCatalogo(id)) {
            throw ErroApi.requisicaoInvalida("Avatar desconhecido.");
        }
        usuarios.atualizarAvatar(u.getId(), id, null); // limpa a imagem personalizada anterior
        u.setAvatar(id);
        u.setAvatarImagem(null);
        return u;
    }

    public Usuario enviarPersonalizado(Usuario u, String dataUrl) {
        String valida;
        try {
            valida = Avatar.validarImagem(dataUrl);
        } catch (IllegalArgumentException e) {
            throw ErroApi.requisicaoInvalida(e.getMessage());
        }
        usuarios.atualizarAvatar(u.getId(), Avatar.PERSONALIZADO, valida);
        u.setAvatar(Avatar.PERSONALIZADO);
        u.setAvatarImagem(valida);
        return u;
    }

    /** Carrega a imagem personalizada (se houver) para responder a /me e ao login. */
    public Usuario comImagem(Usuario u) {
        if (Avatar.PERSONALIZADO.equals(u.getAvatar())) {
            u.setAvatarImagem(usuarios.buscarAvatarImagem(u.getId()));
        }
        return u;
    }
}
